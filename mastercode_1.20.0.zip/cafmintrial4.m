%fun = caobjecfun1;
function[soln]=cafmintrial4()

%% Input

global AA BB CC DD;
% load ip.mat

% Drag Parameters

CD0 = 0.021;
k = 0.175;

% Take-off distance 01,

rho1 = 1.2252;

Sto = 1070;
CLto = 1.434;
alpha1 = 1;

% Landing 02,

rho2 = 1.2252;
% v2 = 
% q2 = 0.5 * rho2 * v2 * v2;
Sland = 1070;
CLland = 1.434;
mu = 0.5;
beta2 = 1;

% Stall 03,

rho3 = 1.2252;
v3 = 64;
q3 = 0.5 * rho3 * v3 * v3;
CLmax = 1.66;

% Sustained Turn 04,

rho4 = 1.2252;
v4 = 135;
q4 = 0.5 * rho4 * v4 * v4;
alpha4 = 1;
beta4 = 1;
n4 = 2;

% Instantaneous Turn Rate 05,

rho5 = 0.8223;
v5 = 102;
q5 = 0.5 * rho5 * v5 * v5;

beta5 = 1;
% turnrate = ; % instantaneous turn rate, deg/s
% n5 = sqrt(1+((turnrate*(pi/180)*v5/9.81)^2))
CLturn = 0.83;
n5 = 2.2;

% Maximum Mach Number 06,

% rho6 = 0.115; % 60,000 feet
% rho6 = 0.1694; % 52,000 feet
rho6 = 0.6527; %20,000 feet
a6 = 316; % 20000 feet

v6 = 77;
q6 = 0.5 * rho6 * v6 * v6;

alpha6 = rho6/1.225*0.1/(v6/a6);
% alpha6 = 1;
beta6 = 0.63;

% Climb rate 07,

rho7 = 1.2252;
v7 = 195;
q7 = 0.5 * rho7 * v7 * v7;

RoC = 7.5;
alpha7 = 1;
beta7 = 1;

%% Constraint Computations

% Take-off distance 01, STO = 1070 m, sea level, alpha = 1, CLtakeoff = 1.434
AA(1) = 0;
BB(1) = 0;
CC(1) = 0;
DD(1) = 1.44/(rho1*CLto*Sto*alpha1*9.807);

% Landing 02, SLAND = 1070 m, sea level, mu=0.5, beta = 1, CLland = 1.434 
AA(3) = 0;
BB(3) = 0;
CC(3) = 0;
DD(3) = Sland*rho2*CLland*mu/(1.69*beta2);

% Stall 03, Vstall = 64 m/s, sea level, CLmax = 1.66

AA(7) = 0;
BB(7) = 0;
CC(7) = 0;
DD(7) = q3*CLmax/9.807;

% Sustained Turn 04, Vturn = 136 m/s, sea level, CD0 = 0.021, k = 0.175, alpha = 1

AA(6) = q4*CD0/(9.807*alpha4); % Missing 9.81 in denom
BB(6) = k*9.807*beta5^2*n4^2/(alpha4*q4); %Missing 9.81 in num
DD(6) = 0;

% Instantaneous Turn Rate 05, Vturn = 102 m/s, 13000 feet, n= 2.22, beta =1

AA(5) = 0;
BB(5) = 0;
CC(5) = 0;
DD(5) = q5*CLturn/(9.807*beta5*n5);

% Maximum Mach Number 06, vman = 191.8 m/s, 15200 m, alpha = 1, beta = 1

AA(4) = q6*CD0/(9.807*alpha6);
BB(4) = k*beta6^2*9.807/(alpha6*q6);
CC(4) = 0;
DD(4) = 0;

% Climb rate 07, RoC = 7.5 m/s, sea level, 192 m/s, alpha = 1, beta = 1

AA(2) = q7*CD0/(9.801*alpha7);
BB(2) = k*beta7^2*9.807/(alpha7*q7);
CC(2) = beta7*RoC/(alpha7*v7);
DD(2) = 0;

%% IP MATRIX FORM FOR REFERENCE

% % Take-off distance 01, STO = 1070 m, sea level, alpha = 1, CLtakeoff = 1.434
% AA(1) = 0;
% BB(1) = 0;
% CC(1) = 0;
% DD(1) = 1.44/(ip(81)*ip(7)*ip(12)*9.807);
% 
% % Landing 02, SLAND = 1070 m, sea level, mu=0.5, beta = 1, CLland = 1.434 
% AA(3) = 0;
% BB(3) = 0;
% CC(3) = 0;
% DD(3) = ip(22)*ip(81)*ip(8)*ip(24)/(1.69*ip(20));
% 
% % Stall 03, Vstall = 64 m/s, sea level, CLmax = 1.66
% 
% AA(7) = 0;
% BB(7) = 0;
% CC(7) = 0;
% DD(7) = ip(74)*ip(75)/9.807;
% 
% % Sustained Turn 04, Vturn = 136 m/s, sea level, CD0 = 0.021, k = 0.175, alpha = 1
% 
% AA(6) = 0.5*ip(62)*ip(64)*ip(64)*ip(1)/(9.801*ip(66));
% BB(6) = ip(2)*ip(65)^2*9.807*ip(58)^2/(ip(66)*0.5*ip(62)*ip(64)*ip(64));
% CC(6) = 0;
% DD(6) = 0;
% 
% % Instantaneous Turn Rate 05, Vturn = 102 m/s, 13000 feet, n= 2.22, beta =1
% 
% AA(5) = 0;
% BB(5) = 0;
% CC(5) = 0;
% DD(5) = ip(56)*ip(55)/(9.807*ip(57)*ip(53));
% 
% % Maximum Mach Number 06, vman = 191.8 m/s, 15200 m, alpha = 1, beta = 1
% 
% AA(4) = 0.5*ip(29)*ip(31)*ip(31)*ip(1)/(9.801*ip(33));
% BB(4) = ip(2)*ip(32)^2*9.807/(ip(33)*0.5*ip(29)*ip(31)*ip(31));
% CC(4) = 0;
% DD(4) = 0;
% 
% % Climb rate 07, RoC = 7.5 m/s, sea level, 192 m/s, alpha = 1, beta = 1
% 
% AA(2) = 0.5*ip(78)*ip(16)*ip(16)*ip(1)/(9.801*ip(18));
% BB(2) = ip(2)*ip(17)^2*9.807/(ip(18)*0.5*ip(78)*ip(16)*ip(16));
% CC(2) = ip(17)*ip(15)/(ip(18)*ip(16));
% DD(2) = 0;

%% Optimisation

lb = [DD(5),0];
ub = [DD(7),1];
A = [-DD(1) 1];
b = [0];
Aeq = [];
beq = [];
x0 = [300,0.3];
%nonlcon = @nonlconstr1;
options = optimoptions('fmincon','Display','iter','Algorithm','sqp');
soln = fmincon(@caobjecfun1,x0,A,b,Aeq,beq,lb,ub,@canonlconstr1, options);
%za = meshgrid(-2:.2:2);
%zb = meshgrid(-2:.2:2);
%zc = 100*(zb-za^2)^2 + (1-za)^2;
%surf(zc,za,zb)

%% Plots
syms x y

figure(9)
yy (x,y) = AA(2) + BB(2)*x.^2 + CC(2)*x - x.*y;
% ezplot(yy);
fig2 = ezplot(yy,[0,500,0.1,1]);
set(fig2,'color','black','LineWidth',2);
M2 = 'Climb Rate';

hold on

yy (x,y) = DD(1)*x;
% ezplot(yy);
fig1 = ezplot(yy,[0,500,0.1,1]);
set(fig1,'color','red','LineWidth',2);
M1 = 'Take-off Distance';

hold on

% ezplot(yy);
yy (x,y) = AA(4) + BB(4)*x.^2 + CC(4)*x - x.*y;
fig4=ezplot(yy,[0,500,0.1,1]);
set(fig4,'color','blue','LineWidth',2);
M4 = 'Maximum Mach Number';

hold on

yy (x,y) = x-DD(5);
% ezplot(yy);
fig5=ezplot(yy,[0,500,0.1,1]);
set(fig5,'color','cyan','LineWidth',2);
M5 = 'Instantaneous Turn';

hold on

% ezplot(yy);
yy (x,y) = AA(6) + BB(6)*x.^2 + CC(6)*x - x.*y;
fig6=ezplot(yy,[0,500,0.1,1]);
set(fig6,'color','magenta','LineWidth',2);
M6 = 'Sustained Turn';

hold on

yy (x,y) = x-DD(7);
% ezplot(yy);
fig7=ezplot(yy,[0,500,0.1,1]);
set(fig7,'color','green','LineWidth',2);
M7 = 'Stall';

grid on
grid minor
title('Constraint Analysis');
legend([fig1, fig2, fig4, fig5, fig6, fig7], M1, M2, M4, M5, M6, M7);
xlabel('Wing Loading (kg/sq.m.)') 
ylabel('Thrust to Weight Ratio')

% syms x y
% yy (x,y) = AA(4) + BB(4)*x.^2 + CC(4)*x - x.*y;
% fig = ezplot(yy,[0,1000,0.1,0.5]);
% 
% yy1 = @(x,y) AA(6) + BB(6)*x.^2 + CC(6)*x - x.*y;
% yy2 = @(x,y) AA(2) + BB(2)*x.^2 + CC(2)*x - x.*y;
% 

end