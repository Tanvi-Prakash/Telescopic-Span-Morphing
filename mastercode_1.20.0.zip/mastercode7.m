% E = [24];
% b = [35.42];

% E = [24,25,26,27,28]

% Baseline Aircraft
clear all
clc

E = 24;
b = 35.42;

height = 18300;
v_cr = 192;

Static_Margin = 25;

% GEOMETRY INPUT - WING

cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m

% GEOMETRY INPUT - TAIL
C_C = 5.972;                    % Distance bet noses of tail root chord and wing root chord, m
cr_t = 1.53;                    % Variable name changed!
ct_t0 = 0.71;                   % Initial tail tip chord, m
% cr_t = 1.833;                 % Tail root chord at centreline, m
b_t0 = 6.948;                   % Initial tail span, m 3.474*2

% AIRCRAFT INITIAL SIZING: BASELINE
[WTO0, EW0, MW0] = Endurance_CL_variation_R1(E)

ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);  
Wing_MAC0 = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% TAIL - INITIAL SIZING: BASELINE

Tail_MAC0 = 2*(cr_t*cr_t + ct_t0*ct_t0 + cr_t*ct_t0)/(3*cr_t+3*ct_t0);
l0 = C_C-(cr - Wing_MAC0)-0.25*Wing_MAC0 + (cr_t-Tail_MAC0)+ 0.25*Tail_MAC0;
Dihedral_Angle = 50;          % Tail dihedral, degrees
D_a = pi()/180 * Dihedral_Angle;
S_h0 = (cr_t + ct_t0) * 0.5*b_t0 * cos(D_a);

HTVC0 = l0 * S_h0/(Wing_MAC0*Sref);

% MORPHED AIRCRAFT : CD0 ESTIMATION

b = [35.42, 37, 39, 40, 41];
% b = [35.42,36];
[CD0, k] = Drag_Module_R2(b);

% MORPHED AIRCRAFT WING GEOMETRY DEFINITION

ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);  
Wing_MAC = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% MORPHED AIRCRAFT TAIL RESIZING
% b=35.42;
[ct_t,b_t,Lift_tail] = Tail_Resizing_ModuleTP_R4(WTO0,height,v_cr, Static_Margin, b,cr,ct0, b_t0,cr_t,ct_t0, HTVC0);

% pause(inf)
%% Wing Mass Section

[Mwing]=Wing_Mass_Module_R2(WTO0,b, cr,ct0)
del_Mwing = Mwing(2:end)- Mwing(1);

%% Actuator Mass Section

% M_act = 100;

M_ext = Mwing .* 0.5.*(Sref-Sref(1))./Sref;     % Approximate mass of extension, kg

Fric_coeff = 0.3;                               % Static friction coefficient
acc_ext = 2.5;                                  % Acceleration, m/s2
F_ext = M_ext*9.81*Fric_coeff + M_ext*acc_ext;

for ii = 1:size(F_ext,2)
F = F_ext(ii);
l = 1000*0.5*(b(ii)-b(1));

selected_actuator = FINDACT_r2(F,l,0);
M_act(ii) = selected_actuator(4);
space_act(ii) = selected_actuator(5);

end

Mass_fudge = 1.20;                  % 20 % installation mass extra
Space_fudge = 1.20;                 % 20 % installation space extra

M_act = (M_act*2)*Mass_fudge;
space_act = (Space_fudge*space_act)/1000;

for ii=1:size(space_act,2)
if space_act(ii) < 0.5*(b(ii)-b(1))
    space_act(ii) = 0.5*(b(ii)-b(1));
end
end

%% Fuel Mass Lost Section

omega = 0.5;                                    % chordwise % of wing-box chord, refer to wing mass module

Fuel_density = 780;
m_fuel_lost = Fuel_density*omega*space_act*0.5.*(ct(1)-ct);

M_act
m_fuel_lost

% pause(inf)

%% Tail Loads Section

Tail_Loads_set = [2300,2400,2500,2600,2700]; % to be refined

%% Tail Mass Section

[Mtail] = Wing_Mass_Module_R2(Tail_Loads_set,b_t, cr_t,ct_t0)
del_Mtail = Mtail(2:end)-Mtail(1);

%% New Weights Section

% size(EW0)
% size(del_Mwing)
% size(del_Mtail)
% size(M_act)

% M_act
% m_fuel_lost

% EW_new = EW0 + del_Mwing + del_Mtail + M_act

Mpayload = 907;
Mfuel0 = WTO0 - EW0 - Mpayload;

EW_new = EW0 - Mwing(1) - Mtail(1) + Mwing + Mtail + M_act
EW_new = EW_new(2:end);
Mfuel = Mfuel0 - m_fuel_lost
Mfuel_lost_new = m_fuel_lost(2:end);

MTOW_new = WTO0+(EW_new-EW0)-Mfuel_lost_new
b_new = b(2:end)
Sref_new = Sref(2:end)


[E]=Endurance_Morphing_R0(b_new, Sref_new, MTOW_new, EW_new)

WTOset(1) = WTO0;
WTOset = [WTOset MTOW_new];

WTOset

pause(inf)
%% PLOT RESIZED WINGS AND TAIL

figure(8)

wingposition = 5.671;

plotwings(cr, ct0, b, wingposition);
hold on

% cr_tail = 1;
% ct_tail = 0.5;
% b_tail = 6;
tailposition = wingposition+C_C;

plotwings(cr_t,ct_t0,b_t,tailposition)


%% CONSTRAINT ANALYSIS CHECK

T = 34100/9.81;

for i=1:size(E,2)
soln = CA_check_R1(WTOset(i),Sref(i),T,CD0(i),k(i),i);  % Dummy check values
end


