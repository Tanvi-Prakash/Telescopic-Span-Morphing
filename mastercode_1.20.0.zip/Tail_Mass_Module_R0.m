function[Mtail]=Tail_Mass_Module_R0(b, cr,ct0,CL_tail,q,cant)
% clear all
% clc

% cr = 2.203;                             % Root chord, m
% ct0 = 0.6778;                            % Tip chord, m
% b = 35.42;                              % Wingspan, m
% b = [35.42, 36, 37, 38,39,46.9];
% WTO = 12134;


% Computed cases for Span extension
% b = [35.42,36,37,38,39,40];
ct = ctip(cr, ct0, b);

Mtail = 10;
Mtail0 = 0;

rh = 0.75; % box depth ratio

%     Sref = 50.6994;  % wing reference area
%     Sref = 50.2;
    Sref = 0.5.*(cr+ct).*b;
    
%     AR = 24.7412; % aspect ratio
%     AR = 35.42*35.42/52.2;
    AR = b.*b./Sref;
    
%     CL = 1;
%     dyn_press = 0.5*0.0841*200*200; % 20000 m altitude
%     
%     cr = 2.178;             % metre
%     cr = 2.258;
%     
%     ct = 0.685;
    lambda = ct./cr;         % ct/cr
    Nlift = 2.5;
    FoS = 1.25;
    ultimatestrength = 572000000/FoS/3.4;           % Fatigue factor added
    shearstrength = 331000000/FoS;
    tau = 0.152;            % (tbyc)
    omega = 0.5;
    rho = 2700;             % Density, (kg/cubic metre)
    
    
while (abs(Mtail-Mtail0)>5)   
    
    Mtail0 = Mtail;
    Ldash = (q*Sref*CL_tail-Mtail0*sin(cant*pi/180))*9.81;   % upward force on wing, N
    
    bendingmoment = (Ldash.*AR*cr.*(1+(2.*lambda)))/24;
    Icap_bar = (Nlift.*bendingmoment*tau)/(2*cr*cr*cr*ultimatestrength);

    for i=1:size(b,2)
    
    s = roots([(0.92*omega*tau),(-0.92*0.92*omega*tau*tau*0.5),(Icap_bar(i))]);
    
%     disp('The first root is: '), disp(s(1));
%     disp('The second root is: '), disp(s(2));

    s1 = s(1);
    s2 = s(2);
    if s1<s2
        rooty = s1;
    else 
        rooty = s2;
    end
    root(i) = rooty;
    end
    
    tcaproot = root*cr;
    tweb_bar = (AR.*Nlift.*Ldash.*(1+(2.*lambda)+(lambda.*lambda)))./(12*tau.*Sref*shearstrength);
    twebroot = tweb_bar*cr;
    Wcap = 0.85*(8*rho*9.81*omega.*root.*(Sref.^1.5).*((lambda.^2)+lambda+1))./(3.*(AR.^0.5).*((1+lambda).^2));
    Wweb = 0.85*(8*rho*9.81*rh*tau*tweb_bar.*(Sref.^1.5).*((lambda.^2)+lambda+1))./(3.*(AR.^0.5).*((1+lambda).^2));
    Mtail = 2*(Wcap + Wweb)/9.81;
   
        Mtail= Mtail-5;
   
end

fprintf('Wing mass is %d kg\n',Mtail)
fprintf('Spar thickness at root is %d mm\n',tcaproot*1000)
fprintf('Skin thickness at root mass is %d mm\n',twebroot*1000)

% Error_wing_percent = (1138-Mwing)*100/1138
end