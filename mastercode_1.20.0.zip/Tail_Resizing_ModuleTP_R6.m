function [ct_t,b_t,Lift_Tail] = Tail_Resizing_ModuleTP_R6(MTOW,height,v_cr, Static_Margin, b, cr,ct0, b_t0,cr_t,ct_t0, HTVC)

% MTOW = 12134;height = 18300;v_cr = 192;Static_Margin=25; b = 35.42;cr=2.203;ct0=0.6778, b_t0=6.948;cr_t = 1.53;ct_t0=0.71; HTVC=0.3488;
ct_t = zeros(size(b));
%% INPUT

offset = 0;
% height = 18300;
[t rho a] = atmosphere(height,offset);

% AIRCRAFT LEVEL INPUT

% MTOW = 12134;               % in kg
% rho = 0.115;              % 65000 feet
% v_cr = 192;                 % Mach 0.65
% Static_Margin = 25;             % Validate 

% GEOMETRY INPUT - WING

% b =35.42;
% S_ref = 50;
% cr = 2.203;                     % Wing Root Chord, m
% ctip = 0.6778;                  % Wing Tip Chord, m


ct = ctip(cr, ct0, b);

S_ref = 0.5*b.*(cr+ct);
Wing_MAC = 2*(cr.*cr + ct.*ct + cr.*ct)./(3*cr+3*ct);
LE_sweep = atan((cr - ct0)./(0.5*b));
AR = b.*b./S_ref;


% GEOMTERY INPUT - TAIL
C_C = 5.972;                    % HARD CODED Distance bet noses of tail root chord and wing root chord, m
% cr_t_fus = 1.53;
% cr_t = 1.53;                        % Variable name changed!
% ct_t0 = 0.71;                   % Initial tail tip chord, m
% cr_t = 1.833;                 % Tail root chord, m
% b_t0 = 3.474;                 % Initial tail span, m CHECKWITHSOMRICK
% b_t0 = 6.948;                 % Initial tail span, m 3.474*2

Dihedral_Angle = 50;              % HARD CODED Tail dihedral, degrees
Tail_angle = 90 - Dihedral_Angle;
D_a = pi()/180 * Dihedral_Angle;        % Check with Somrick
T_a = pi()/180 * Tail_angle;

% Tail_MAC = 2*(cr_t*cr_t + ct_t0*ct_t0 + cr_t*ct_t0)/(3*cr_t+3*ct_t0);

% HTVC = 0.3488;                      % Target HTVC Value

% RUDDERVATOR GEOMETRY

% Control_SA = 1.232;               % < Ruddervator area (slant), sq. m.

ControlSurface_Chord = 1.232/(b_t0*0.5);         % GLOBAL HAWK ONLY!
Control_SA = ControlSurface_Chord*b_t0*0.5;

% GEOMETRY INPUT - AIRFOILS

CL_alpha_LRN1015 = 6.270;       % 2D lift curve slope in radians
CL_alpha_NACA0012 = 6.191;      % 2D lift curve slope in radians

% FIXED AERODYNAMIC DERIVATIVES (from XFLR5)

CL_alpha_Aircraft_0 = 0.491;                % Intercept value, HARD-CODED
Cm_0 = -0.5069;                             % y-intercept HARD CODED
Cm_Alpha_F = 0.5649;                        % HARD CODED Check source with Somrick: About root chord nose



%% Tail Resizing Module

k1 = C_C-cr+0.75*Wing_MAC+cr_t;
k2 = 0.5*cos(D_a)*b_t0/(cr_t-ct_t0);

a1 = 0.5*k2;
b1 = -k1*k2;
c1 = 0;
d1 = (k1*k2*cr_t*cr_t)-(0.5*k2*cr_t*cr_t*cr_t)-(HTVC.*Wing_MAC.*S_ref);

for j = 1:size(d1,2)
p = [a1 b1(j) c1 d1(j)];

ct_roots = roots(p);

for i = 1:3
if ct_roots(i) < 1 && ct_roots(i)>0
    ct_t(j) = ct_roots(i);
end
end
% ct_t(j);
end

b_t = b_t0 * (cr_t-ct_t)/(cr_t-ct_t0);

S_h = 0.5*b_t.*(cr_t+ct_t);

Tail_MAC = 2*(cr_t.*cr_t + ct_t.*ct_t + cr_t.*ct_t)./(3*cr_t+3*ct_t);
l = C_C-(cr - Wing_MAC)-0.25*Wing_MAC + (cr_t-Tail_MAC)+ 0.25*Tail_MAC;


%% AoA and Elevator Deflection Calculations

% Half_Tail_Area = S_h/(2*cos(1.13446));      % Half tail Area actual, check with Somrick
% Half_Tail_Area_Exposed = 0.5*(cr_t+ct_t)*b_t; % Exposed half tail area

Half_Tail_Area = 0.5*(cr_t+ct_t).*b_t; % Exposed half tail area

Area_ratio = Control_SA./Half_Tail_Area;
Tau = -4.3443*(Area_ratio.^4) + 8.0198*(Area_ratio.^3) - 5.9526*(Area_ratio.^2) + 2.8361*Area_ratio + 0.0205;
%Cl_trim = 1.0679;                          % CL at trim condition of angle of 0.0960763 radian
T_AR = 3;                                   % HARD CODED, check with Somrick

T = 1+tan(LE_sweep).*tan(LE_sweep);

e_wing = 2./(2-AR+sqrt(4+AR.*AR.*T));          % Oswald efficiency of wing
k = 1./(pi*AR.*e_wing);

CL_alpha_W= CL_alpha_LRN1015./(1+k*CL_alpha_LRN1015);

e_tail = 2./(2-T_AR+sqrt(4+T_AR*T_AR.*T));    % Check with Somrick

CL_alpha_T = CL_alpha_NACA0012./(1+CL_alpha_NACA0012./(pi*e_tail.*T_AR));

d_eps_alpha = 2*CL_alpha_W./AR;

CL_alpha_Aircraft = CL_alpha_W+ CL_alpha_T.*(1-d_eps_alpha)*2.*Half_Tail_Area./b;

CL_trim = MTOW*9.81./(0.5*rho*v_cr*v_cr.*S_ref); % Coefficient of trim at level flight with MTOW

Alpha_trim = (CL_trim - CL_alpha_Aircraft_0)./CL_alpha_Aircraft; % Alpha, radians
Alpha_trim_d = Alpha_trim * 180/pi() ;          % Alpha, degrees

%Alpha_trim = 4.12 degree
% CL_tail = CL_alpha_T .* Alpha_trim.*S_h./S_ref;

eta = 1;                                            % HARD CODED

C_m_delEps = - HTVC * eta .* CL_trim .* Tau;          % Elevator effectiveness Parametre
% disp("The elevator effectiveness is given by:"), disp(C_m_delEps);

% CL_delEps = CL_alpha_T.*Tau*eta.*S_h./S_ref

Cm_alpha = - CL_alpha_W * Static_Margin/100;

%delta_trim = -(Cm_o*Cl_alpha_T + Cm_alpha_slope*Cl_trim)/(C_m_delEps*Cl_alpha_T - Cm_alpha*Cl_deltaE);

delta_trim1 = -(Cm_0 + Cm_alpha.*Alpha_trim)./C_m_delEps;
% disp("Elevator Trim angle is:"), disp(delta_trim1);

CL_delEps = -C_m_delEps.*Wing_MAC/l;
epsilon = 2*CL_alpha_W.*Alpha_trim./(pi()*AR);
CL_Tail = CL_alpha_T.*(Alpha_trim-epsilon) + CL_delEps.*delta_trim1;
Lift_Tail = 0.5*CL_Tail.*v_cr.*v_cr.*rho.*S_h;

X_AC = cr - Wing_MAC + 0.25 * Wing_MAC;
X_NP = X_AC - Wing_MAC.*(Cm_Alpha_F./CL_alpha_W) + Wing_MAC*eta.*HTVC.*(1-d_eps_alpha).*CL_alpha_T./CL_alpha_W;

X_CG = X_NP - Static_Margin * Wing_MAC/100;

inputs = [Static_Margin;b;cr;ct0;b_t0;cr_t;ct_t0;HTVC];
results = [ct_t; b_t; Lift_Tail; CL_Tail; S_h; CL_alpha_Aircraft; CL_alpha_T; Alpha_trim*180/pi(); epsilon*180/pi(); (Alpha_trim-epsilon)*180/pi(); CL_delEps; delta_trim1*180/pi(); Cm_0; Cm_alpha; C_m_delEps];

filename = 'Tail_Resizing_Results_R0.xlsx';
inputheadings = {'SM %';'Wingspan';'Wing Root Chord';'Wing Tip Chord initial';'Initial tailspan';'Tail root chord';'Tail tip chord initial';'HTVC'};
headings = {'RESULTS OF TAIL RESIZING (Tail_Resizing_Module_R4)';'Tail tip chord (m)';'Tail span (m)';'Tail Lift (N)';'CL tail';'Tail ref area (sq.m.)';'CL alpha aircraft';'CL alpha tail';'Alpha trim';'epsilon';'Alpha trim - epsilon';'CL_delEps';'delE';'Cm_0'; 'Cm_alpha'; 'C_m_delEps'};

writecell(inputheadings,filename,'Sheet',1,'Range','A2');
writematrix(inputs,filename,'Sheet',1,'Range','B2');

writecell(headings,filename,'Sheet',1,'Range','C2');
writematrix(results,filename,'Sheet',1,'Range','D3');

% Tail_Load = 0.5 * rho * v_cr*v_cr * (S_ref .* CL_tail + CL_delEps .* (delta_trim1-epsilon))

%disp(Cm_alpha);


end