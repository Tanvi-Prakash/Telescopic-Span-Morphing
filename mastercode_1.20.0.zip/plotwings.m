function plotwings(c_r, c_tip_0, b, x_nose)

c_tip = ctip(c_r, c_tip_0, b);

for i=1:size(b,2)

    x=[0.5*b(i) 0.5*b(i) 0 -0.5*b(i) -0.5*b(i)];
    y=[-x_nose c_tip(i)-x_nose c_r-x_nose c_tip(i)-x_nose -x_nose];
    fig8=fill(x, y, '');
set(fig8,'facealpha',.2);
axis equal

hold on
end
end