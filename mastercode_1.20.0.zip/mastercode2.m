WTOset = endurance_module
wstw = cafmintrial4
Sset = WTOset./wstw(1)

bset=sqrt(Sset.*25);
bsetby2 = bset/2;

cr = (Sset./bset) + (0.25*bset*tan(5*pi/180));  % height 
ct = cr- (0.5*tan(5*pi/180).*bset);

% a = 2 ;  % top side
% b = 4 ;   % base 
% %%Frame vertices
% A = [0 0] ;
% B = [bsetby2 0] ;
% C = [bsetby2 ct] ;
% D = [0 cr] ;  
% coor = [A ; B; C; D] ;  
% patch(coor(:,1), coor(:,2),'r')

figure(2)
for i=1:7
hold on
fig = plot([0 bsetby2(i)],[cr(i) ct(i)])
hold on
'check'
end