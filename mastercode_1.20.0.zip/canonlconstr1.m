function [c,ceq] = canonlconstr1(x)
global AA BB CC;
c = [AA(2) + BB(2)*x(1)^2 + CC(2)*x(1) - x(1)*x(2);
     AA(6) + BB(6)*x(1)^2 + CC(6)*x(1) - x(1)*x(2);
     AA(4) + BB(4)*x(1)^2 + CC(4)*x(1) - x(1)*x(2)];
ceq = [];