function [output_findact] = FINDACT_r1(x,y,n)
% clear all


% n = 0 for minimum mass, 1 for force based ballparking
% x
% y

% 
% load input.mat

% load hyd.mat
% load pneum.mat
% load elec.mat

load combine.mat

% %% ----- READ INPUT ----- %%
% reqd(1) = x;                % stroke
% reqd(2) = y;                % force

%% -------- Test variable selection ------- %

% choice = 3;
% value  = 5000;
% 
% % choice = 2;
% value = 2000;
% 
% choice = 1;
% value = 2;
%% SAMPLE INPUT DATA

% reqd = [3750,8000];
% n=1;

reqd = [x,y];

%% FINDACT 

% %% ----- SORT DATA HYD ----- %
% 
% hyd =[nhyd shyd fhyd mhyd lhyd idhyd];
% hyd = sortrows(hyd);

% %% ----- SORT DATA PNEUM ----- %
% 
% pneum =[npneum spneum fpneum mpneum lpneum idpneum];
% pneum = sortrows(pneum);

% %% ----- SORT DATA ELEC ----- %
% 
% elec =[dummy selec felec melec lelec idelec];
% elec = sortrows(elec);

%% ----- SORT DATA COMBINE ----- %

combine =[nhyd shyd fhyd mhyd lhyd idhyd;npneum spneum fpneum mpneum lpneum idpneum;dummy selec felec melec lelec idelec];
combine(:,6)=1:size(combine);           % assign serial numbers in last column
combine = sortrows(combine,2);          % sort by stroke

%% ----- FIND MINIMUM MASS TO SATISFY ----- %

% % --- find solutions that provide stroke ---
% ans1 = find(hyd(:,2)>reqd(1));
% cand1 = hyd(ans1,:);

% % --- find solutions that provide stroke ---
% ans1 = find(pneum(:,2)>reqd(1));
% cand1 = pneum(ans1,:);

% % --- find solutions that provide stroke ---
% ans1 = find(elec(:,2)>reqd(1));
% cand1 = elec(ans1,:);

% c1=clock;

% --- find solutions that provide stroke ---
ans1 = find(combine(:,2)>reqd(1));
cand1 = combine(ans1,:);

% --- find solutions that provide force ---
ans2 = find(cand1(:,3)>reqd(2));
cand2 = cand1(ans2,:);

%% n=0

if n==0
% --- find mimimum mass --- CHECK AS IT DOESNT FIND MINUMUM STAGES
[mini, i] = min(cand2(:,4));
selected = cand2(i,:);

% c2=clock;

if(selected(6)<(size(nhyd,1)+1))
    fprintf('Hydraulic No. %d .\n', selected(6))
else if (selected(6)<(size(nhyd,1)+size(npneum,1)+1))
        fprintf('Pneumatic No. %d .\n', selected(6))
    else fprintf('Electrical No. %d .\n', selected(6))
    end
end

end
%% n=1

if n==1
  'Force-based Ballparking'                 % IMP, force & stroke are 'reversed here
  ans2a = [cand1(size(cand1,1)-size(cand2,1)); ans2];    % only one lower value considered
  cand2a = cand1(ans2a,:);                   %
  
  s=sortrows(cand2a,4);                     % sort based only on mass, not space
  
  diff=abs(cand2a(:,3)-reqd(2));
  [minm,imin]= min(diff);
  
  temp=sort(diff);
  
  imin2=find(diff == temp(2));
  i=[imin;imin2];
  
  ballparkends=cand2a(i,:)
  diff = ballparkends(:,3)-reqd(2);
  size(ballparkends);
  ratio1=abs(diff./(ballparkends(1,3)-ballparkends(size(ballparkends,1),3)))
  % sumz = sum(unique(ratio1))
   ratio=unique(ratio1);
%   ballparks = unique(ballparkends)
%    
%   answerz=sum(ratio.*ballparks(:,2))

selected = [0 (ratio(1)*ballparkends(1,2)+ratio(2)*ballparkends(2,2)) (ratio(1)*ballparkends(1,3)+ratio(2)*ballparkends(2,3)) (ratio(1)*ballparkends(1,4)+ratio(2)*ballparkends(2,4)) (ratio(1)*ballparkends(1,5)+ratio(2)*ballparkends(2,5)) (ratio(1)*ballparkends(1,6)+ratio(2)*ballparkends(2,6))];


end
%% Collate output variable

% output_findact = [selected;c1;c2]

output_findact = [selected]


end
% 
% if n==2
%     'Stroke-based Ballparking'
%     
% end


