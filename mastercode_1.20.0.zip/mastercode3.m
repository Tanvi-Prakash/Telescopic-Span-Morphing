% E = [24];
% b = [35.42];

E = [24,25,26,27,28]
b = [35.42, 37, 39, 40,41]

[CD0, k] = Drag_Module_R2(b)
WTOset = Endurance_CL_variation_R0(E,CD0,k)


% wstw = cafmintrial4;
soln = CA_check_R0(WTOset,S,T,CD0,k);  % Dummy check values
Sset = WTOset./wstw(1);

bset=sqrt(Sset.*25);
bsetby2 = bset/2;
        
cr = (Sset./bset) + (0.25*bset*tan(5*pi/180));  % height 
ct = cr- (0.5*tan(5*pi/180).*bset);

% a = 2 ;  % top side
% b = 4 ;   % base 
% %%Frame vertices
% A = [0 0] ;
% B = [bsetby2 0] ;
% C = [bsetby2 ct] ;
% D = [0 cr] ;  
% coor = [A ; B; C; D] ;  
% patch(coor(:,1), coor(:,2),'r')

% figure(2);
% for i=1:7
% hold on
% fig = plot([0 bsetby2(i)],[cr(i) ct(i)]);
% hold on
% 'check';
% end

figure(8)

wingposition = 5.670639594;

% plotwings(cr, ct, bset, wingposition(1))
% hold on

cr_tail = 1;
ct_tail = 0.5;
b_tail = 6;
tailposition = 9;

% plotwings(cr_tail,ct_tail,b_tail,tailposition)

[Mwing]=Wing_Mass_Module_R2(WTOset,b, cr,ct0)