function [CD0, k] = Drag_Module_R2(b)
% R2: MAC replaces cr in lbyk formula
%% HARD CODED INPUT VARIABLES

% Geometric Variables

% Hard-coded case

cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m
% b = 35.42;                              % Wingspan, m

% Computed cases for Span extension
% b = [35.42,36,37,38,39,40];
ct = ctip(cr, ct0, b);
t_1 = ct./cr;

fusd = 1.4478;                          % Fuselage diameter, m

fusl0 = 14.508;                          % Fuselage length, m
% increase=[0,0.789402034350318,0.963557319527248,1.21822528981707,1.62597598077565,2.38405175350547];

% lostfuel = [0,250,500,750,1000,1200];
% increase = lostfuel./(pi()*800*fusd);
increase = 0;                           % increase in fuselage length, m

% fusl = fusl0;
fusl = increase + fusl0;



% a1 = 295.07;                            % Speed of sound at 65000 feet, m/s
height = 65000*.3048;                        % 65000 ft in m  
[t, rho, a1] = atmosphere(height,0);

% Drag Related Variables

tbyc = 0.15;                            % Airfoil maximum thickness ratio
rh = 0.00025;                           % Surface Roughness Value, inch, Smooth Matte Paint
M = 0.65;                               % Design Mach Number
RE_l = 2.100E+06;                       % Reference Reynolds number < check value

%% Wing Parameters

% Sref = 0.5*(ct+cr)*b;                   % reference area calculated, sq.m.                 % < only base case being taken
Sref = 0.5.*b.*(cr+ct);                         % half wing area

AR = b.*b./Sref;
e = 2./(2-AR+sqrt(4+AR.*AR));
k = 1./(pi*e.*AR);

Swet_wing = (Sref*2)-(2*fusd*cr);
Swet_fuselage = pi()*fusl*fusd;         % < only base case being taken here
Swet = 1.2*(Swet_wing+Swet_fuselage);   % Wetted area, sq. m.                  % < only base case being taken here

SwbySr = Swet./Sref;                     % Ratio of wetted area to reference area   % < only base case being taken here
                                        % < only base case being taken here
lesweep = 180*atan((cr-ct)./(0.5*b))/pi();

%% ________ DRAG ESTIMATION _________
% Cfe = 0.004;
% CD0 = Cfe*SwbySr;

% Aerodynamic Input

deltbycrad = atan(1.2*(cr-ct)./b);       % Max tbyc sweep angle, radians
deltbycdeg = deltbycrad*180/pi;         % Max tbyc sweep angle, degrees
R = 0.6967*cos (deltbycrad)+ 0.5442;    % lifting surface correlation Factor

% Fuselage

% lostfuel = pi()*increase.*fusd*800;

fus_fine = fusl./fusd;                  % < only base case being taken
Sb = pi()*fusd*fusd/4;
Ss = pi()*fusl*fusd;                    % < only base case being taken

%MAC Wing
mac = (2*cr.*(1+t_1+(t_1.^2)))./(3*(1+t_1)) ;                        % (Nicolai, Fig 2.1) 

lbyk = mac.*39.37/rh;                     % < is OK?

RE_cutoff = 38.21*(lbyk.^1.053);
RE_actual = 0.0906838 * M * a1 * cr/0.0000143226;   % < is OK?

for i=1:size(RE_cutoff,2)
RE_sel(i) = min(RE_cutoff(i), RE_actual);
end
Cf = (0.455./((log10(RE_sel)).^2.58)-(1700./RE_sel));  % Flat plate skin friction coeff

SsbySb = Ss/Sb;                         % < only base case being taken
CD0_body = Cf.*SsbySb.*(1+(60./(fus_fine.^3))+(0.0025.*(fus_fine)))*Sb./Sref;                 % < only base case being taken

% Wing

SwbySref_wing = Swet_wing./Sref;                     % < only base case being taken

CD0_wing = Cf.*R.*SwbySref_wing*(1+(1.2*tbyc)+(100*(tbyc^4)));    % < only base case being taken

% Miscellaneous

CD0_boattail = 0.00125*280/540;                     % < is OK?
% CD0_boattail = 0;
CD0_canopy = 0.0006*280./(10.7639*Sref);            % < is OK?
CD0_protub = 0.0014*280./(10.7639*Sref);            % < is OK?
CD0_stores = 0*280/540;                             % < is OK?
% CD0_stores = 0;

% Total

CD0 = CD0_wing+CD0_body+CD0_boattail+CD0_canopy+CD0_protub+CD0_stores;
end