clear all
clc

% Mastercode 11: discussed with Prof 10 Sept 2022

% Mastercode 12: areal density of wing and tail used to resize wing and tail

% Mastercode 13: Return to iterative procedure: Post APS, M-fixed approach

% Mastercode 14: Fresh attempt at for loop

% Mastercode 15: Photomorphing implemented (Tail_Resizing_ModuleTP_R7)

% Mastercode 16: FINDACT with Force-Based Ballparking

% Mastercode 17: initialise wing and tail mass temp1/temp2;
%                   dMwing, dMtail, dM_act, dMfuel used to calculate new Endurance at the end

% Mastercode 18: Wing mass module R3 modified to give non negative tailmass

% Mastercode 19: above didnt work. found that tail loads was in Newton.
%                   It is now corrected here

% Mastercode 20: Implement non-FINDACT estimation of Force and Stroke
% 7_1: with findact as before, force based ballparking
% 7_2: with linearised actuator model
% 7_3: piecewise linear actuator model
% 7_4: ignore mass of fuel lost in wing with 7_3
% 7_5: ignore mass of fuel lost in wing with 7_2
% 7_6: wing weight estimation per unit area with reinforcement factor = 2
% 7_7: wing weight estimation per unit area with reinforcement factor = 5
%       output excel sheet cleaned up to give results column wise,
%       housekeeping done on various plotted values
% 7_8: wing weight estimation per unit area with reinforcement factor = 3.5
% 7_9: wing weight estimation per unit area with reinforcement factor = 1

% TO RUN 7_10 and 7_11 with 7_5 and 7_4 including fuselage drag increase


%% INPUT

% BASELINE AIRCRAFT PARAMETERS

E = 24;
b = 35.42;

height = 18300;
v_cr = 192;

Static_Margin = 25;

% GEOMETRY INPUT - WING

cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m

% GEOMETRY INPUT - TAIL
C_C = 5.972;                    % Distance bet noses of tail root chord and wing root chord, m
cr_t = 1.53;                    % Variable name changed!
ct_t0 = 0.71;                   % Initial tail tip chord, m
% cr_t = 1.833;                 % Tail root chord at centreline, m
b_t0 = 6.948;                   % Initial tail span, m 3.474*2

% AIRCRAFT INITIAL SIZING: BASELINE
[WTO0, EW0, MW0] = Endurance_CL_variation_R2(E);


ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);
Wing_MAC0 = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% TAIL - INITIAL SIZING: BASELINE

Tail_MAC0 = 2*(cr_t*cr_t + ct_t0*ct_t0 + cr_t*ct_t0)/(3*cr_t+3*ct_t0);
l0 = C_C-(cr - Wing_MAC0)-0.25*Wing_MAC0 + (cr_t-Tail_MAC0)+ 0.25*Tail_MAC0;
Dihedral_Angle = 50;          % Tail dihedral, degrees
D_a = pi()/180 * Dihedral_Angle;
S_h0 = (cr_t + ct_t0) * 0.5*b_t0 * cos(D_a)

HTVC0 = l0 * S_h0/(Wing_MAC0*Sref);

%% Original Weights Section

Mpayload = 907;
Mfuel0 = WTO0 - EW0 - Mpayload;
% EW0
% WTO0

%% MORPHED AIRCRAFT DEFINITION

% b = [35.42, 36, 36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40, 40.5, 41,41.5, 42,42.5,43,43.5,44,44.2];

b = [35.42, 36, 37, 38, 39, 40, 41, 42,43,44,44.2];

% b=35.42;


% MORPHED AIRCRAFT : CD0 ESTIMATION

[CD0, k] = Drag_Module_R2(b);

% MORPHED AIRCRAFT WING GEOMETRY DEFINITION

ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);  
Wing_MAC = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% pause(inf)

%% FINDING M-FIXED

Mwing(1) = Wing_Mass_Module_R3(WTO0,b(1), cr,ct0);

% b(1)

% [ct_t(1),b_t(1),Lift_tail(1)] = Tail_Resizing_ModuleTP_R6(WTO0,height,v_cr, Static_Margin, b(1),cr,ct0, b_t0,cr_t,ct_t0, HTVC0);

[ct_t(1),b_t(1),Lift_tail(1)] = Tail_Resizing_ModuleTP_R7(WTO0,height,v_cr, b(1), cr,ct0, b_t0,cr_t,ct_t0, HTVC0)

Tail_Loads_set(1) = Lift_tail(1)/(9.81*cos(D_a))        % Newton to kg          % Convert lift to spanwise loading

Mtail(1) = Wing_Mass_Module_R3(Tail_Loads_set(1),b_t(1), cr_t,ct_t0)

M_fixed = WTO0 - (Mwing(1)+Mtail(1)+Mfuel0)

temp1 = Mwing(1);
temp2 = Mtail(1);
temp22 = Tail_Loads_set(1);
temp23 = b_t(1);
temp24 = ct_t(1);
temp25 = Lift_tail(1);
%% INITIALISATIONS

dM_wing = zeros(1,size(b,2));
dM_tail = zeros(1,size(b,2));
dM_act = zeros(1,size(b,2));
dM_fuel = zeros(1,size(b,2));
% dMTOW_guess = zeros(1,size(b,2));
M_act = zeros(1,size(b,2));
space_act = zeros(1,size(b,2));
F_ext = zeros(1,size(b,2));
m_fuel_lost = zeros(1,size(b,2));
Mwing = zeros(1,size(b,2));
Mwing(1) = temp1;
Mtail = zeros(1,size(b,2));
Mtail(1)=temp2;
ct_t = zeros(1,size(b,2));
ct_t(1) = temp24;                       %18
b_t = zeros(1,size(b,2));
b_t(1) = temp23;                        %18
Lift_tail = zeros(1,size(b,2));
Lift_tail(1) = temp25;                  %18
Tail_Loads_set = zeros(1,size(b,2));
Tail_Loads_set(1)= temp22;              %18
M_ext = zeros(1,size(b,2));
MTOW_temp = 13000;
whilecount = 0;
F = zeros(1,size(b,2));
l = zeros(1,size(b,2));
excessMwing = zeros(1,size(b,2));       % 20 7_6
increase = zeros(1,size(b,2));

dMTOW_guess =  2000 * (ones(1,size(b,2)));

MTOW_guess = [WTO0 12500*ones(1,size(b,2)-1)];
size(b,2)

% pause(inf)


%% (OUTER) FOR LOOP: TAKING ONE MORPHED SPAN AT A TIME

stop_criteria = 5;      % WHILE loop criteria

MTOW_step = 5;         % MTOW reduction at every step


for mu = 2:size(b,2)                % mu = index of each new span
mu;
MTOW_guess(mu) = MTOW_guess(mu-1)+50;
    while(abs(MTOW_guess(mu)-MTOW_temp)>stop_criteria)
        whilecount = whilecount + 1;
        if ((MTOW_guess(mu)-MTOW_temp) > 0)
        MTOW_guess(mu) = MTOW_guess(mu) - MTOW_step
        else
        MTOW_guess(mu) = MTOW_guess(mu) + MTOW_step
        end
%% CHANGE IN MASSES
% % (upto 7_5) WING MASS FOR MORPHED CONFIG

Mwing(mu)=Wing_Mass_Module_R3(MTOW_guess(mu),b(mu), cr,ct0);
% 
% % 7_6 Proportional Wing Mass Model
% 
% WingAreaDensity = Mwing(1)/Sref(1);
% 
% dSref = Sref(mu)-Sref(1);
% M_ext(mu) = dSref * WingAreaDensity;
% 
% % WingMassFudge = 2;              % Factor on mass of extending part for reinforcement
% % WingMassFudge = 3.5;
% WingMassFudge = 1;
% % WingMassFudge = 5;
% 
% excessMwing(mu) = M_ext(mu) * WingMassFudge;
% 
% Mwing(mu) = Mwing(1) + excessMwing(mu);

% TAIL MASS FOR MORPHED CONFIG
% [ct_t(mu),b_t(mu),Lift_tail(mu)] = Tail_Resizing_ModuleTP_R6(MTOW_guess(mu),height,v_cr, Static_Margin, b(mu),cr,ct0, b_t0,cr_t,ct_t0, HTVC0);

[ct_t(mu),b_t(mu),Lift_tail(mu)] = Tail_Resizing_ModuleTP_R7(MTOW_guess(mu),height,v_cr, b(mu), cr,ct0, b_t0,cr_t,ct_t0, HTVC0);


Tail_Loads_set(mu) = Lift_tail(mu);                            % Convert lift to spanwise loading

Mtail(mu) = Wing_Mass_Module_R3(Tail_Loads_set(mu),b_t(mu), cr_t,ct_t0);

% ACTUATOR MASS / SPACE FOR MORPHED CONFIG

M_ext(mu) = Mwing(mu) .* 0.5.*(Sref(mu)-Sref(1))./Sref(mu);     % Approximate mass of extension, kg

Fric_coeff = 0.3;                               % Static friction coefficient
acc_ext = 2.5;                                  % Acceleration, m/s2
F_ext(mu) = M_ext(mu)*9.81*Fric_coeff + M_ext(mu)*acc_ext;

F(mu) = F_ext(mu);
l(mu) = 0.5*(b(mu)-b(1));

% FINDACT Replacement Code Mastercode 20 - Single linear actuator model

M_act(mu) = 46.74954675 * l(mu);

space_act(mu) = 0.3975653976 * l(mu);

% % Piecewise linear actuator model
% 
% if l(mu) <0
%     'negative span extension'
% end
% if l(mu)<1.829
%     M_act(mu) = 21.86987425*l(mu);
%     space_act(mu) = 0.633679606*l(mu);
% end
% if l(mu)>=1.829 & l(mu)<3.810
%         M_act(mu) = 83.79606259*l(mu)-113.2629985;
%         space_act(mu) = 0.322059566*l(mu)+0.569953054;
% 
% end
% if l(mu)>=3.810 & l(mu)<8.000
%         M_act(mu) = 39.62167689*l(mu)+55.04141104;
%         space_act(mu) = 0.325408998*l(mu)+0.557191718;
% 
% end
% if l(mu)>=8.000 
%     'span extension > 8.000'
% end


% selected_actuator = FINDACT_r4(F,l,0);

% selected_actuator = FINDACT_r4(F(mu),l(mu),1);

% M_act(mu) = selected_actuator(1,4);

% space_act(mu) = selected_actuator(1,5)/1000;

Mass_fudge = 1.20;                  % 20 % installation mass extra
Space_fudge = 1.20;                 % 20 % installation space extra

M_act(mu) = (M_act(mu)*2)*Mass_fudge;
space_act(mu) = Space_fudge*space_act(mu);

if space_act < 0.5*(b(mu)-b(1))
    space_act(mu) = 0.5*(b(mu)-b(1));
end

% FUEL LOST FOR MORPHED CONFIG

% omega = 0.5;                                    % chordwise % of wing-box chord, refer to wing mass module
omega = 0.7;                                    % increased in mastercode15

Fuel_density = 780;

% m_fuel_lost(mu) = Fuel_density*omega*space_act(mu)*0.5.*(ct(1)-ct(mu));

% mastercode 20:
m_fuel_lost(mu) = Fuel_density*omega*space_act(mu).*ct(1);     % changed in mastercode 15 to ct(1)

%added for 7_10 for increase in fuselage size
increase(mu) = (m_fuel_lost(mu)/780)/(pi*0.25*1.44*1.44);

% % ignoring mass if fuel lost 20230624
m_fuel_lost(mu) = 0;

%% MASS UPDATE
        MTOW_temp = M_fixed + Mwing(mu) + Mtail(mu) + M_act(mu) + Mfuel0 - m_fuel_lost(mu) ;
%% LOG ITERATION DATA

t = now;
d = datetime(t,'ConvertFrom','datenum');

iter_output(whilecount,:) = [MTOW_guess(mu) Mwing(mu) Mtail(mu) M_act(mu) m_fuel_lost(mu) MTOW_temp M_fixed b(mu) b_t(mu) Lift_tail(mu)];

filename = 'Iteration Data R7_10.xlsx';
headings = {'Iteration Data'};
% results = [dM_wing;dM_tail;dM_act;dM_fuel;dMTOW_guess];
writematrix(d,filename,'Sheet',mu,'Range','A1');
writecell(headings,filename,'Sheet',mu,'Range','C2');
writematrix(iter_output,filename,'Sheet',mu,'Range','D2');
    end % WHILE LOOP END
end     % FOR LOOP END

% %% (OUTER) FOR LOOP: TAKING ONE MORPHED SPAN AT A TIME (old)
% 
% for mu = 1:size(b,2)                % mu = index of each new span
% mu;                                 % Morphed span number
% count = 1;                          % Reset While-Loop Iteration counter
% 
% %% (INNER) WHILE LOOP: TO ARRIVE AT MTOW FOR THIS SPAN (old)
% 
%     while ((dMTOW_guess(mu) - abs(MTOW_guess(mu)-WTO0))>5)
% mu*2;
% count;
% %% CHOOSING A GUESS MTOW (old)
% 
%     if dMTOW_guess(mu) > MTOW_guess(mu) - WTO0
%         MTOW_guess(mu) = MTOW_guess(mu)-10;
%     end
% 
%     if dMTOW_guess(mu) < MTOW_guess(mu) - WTO0
%         MTOW_guess(mu) = MTOW_guess(mu)+10;
%     end

% %% WING MASS FOR MORPHED CONFIG (old) 
% 
% Mwing(mu)=Wing_Mass_Module_R2(MTOW_guess(mu),b(mu), cr,ct0);
% 
% %% TAIL MASS FOR MORPHED CONFIG
% [ct_t(mu),b_t(mu),Lift_tail(mu)] = Tail_Resizing_ModuleTP_R4(MTOW_guess(mu),height,v_cr, Static_Margin, b(mu),cr,ct0, b_t0,cr_t,ct_t0, HTVC0);
% Tail_Loads_set(mu) = Lift_tail(mu)/cos(D_a);                            % Convert lift to spanwise loading
% 
% Mtail(mu) = Wing_Mass_Module_R2(Tail_Loads_set(mu),b_t(mu), cr_t,ct_t0);
% 
% %% ACTUATOR MASS / SPACE FOR MORPHED CONFIG
% 
% M_ext(mu) = Mwing(mu) .* 0.5.*(Sref(mu)-Sref(1))./Sref(mu);     % Approximate mass of extension, kg
% 
% Fric_coeff = 0.3;                               % Static friction coefficient
% acc_ext = 2.5;                                  % Acceleration, m/s2
% F_ext(mu) = M_ext(mu)*9.81*Fric_coeff + M_ext(mu)*acc_ext;
% 
% F = F_ext(mu);
% l = 1000*0.5*(b(mu)-b(1));
% 
% selected_actuator = FINDACT_r2(F,l,0);
% M_act(mu) = selected_actuator(1,4);
% 
% space_act(mu) = selected_actuator(1,5)/1000;
% 
% Mass_fudge = 1.20;                  % 20 % installation mass extra
% Space_fudge = 1.20;                 % 20 % installation space extra
% 
% M_act(mu) = (M_act(mu)*2)*Mass_fudge;
% space_act(mu) = Space_fudge*space_act(mu);
% 
% if space_act < 0.5*(b(mu)-b(1))
%     space_act(mu) = 0.5*(b(mu)-b(1));
% end
% 
% % FUEL LOST FOR MORPHED CONFIG
% 
% omega = 0.5;                                    % chordwise % of wing-box chord, refer to wing mass module
% 
% Fuel_density = 780;
% 
% m_fuel_lost(mu) = Fuel_density*omega*space_act(mu)*0.5.*(ct(1)-ct(mu));

% %% RESET GUESS MTOW BASED ON ABOVE VALUES (old)
% 
% dM_wing(mu) = Mwing(mu)-Mwing(1);
% dM_tail(mu) = Mtail(mu)-Mtail(1);
% dM_act(mu) = M_act(mu)-M_act(1);
% dM_fuel(mu) = m_fuel_lost(mu);
% 
% dMTOW_guess(mu) = dM_wing(mu) + dM_tail(mu) + dM_act(mu) - dM_fuel(mu);

% %% SAVE ITERATION OUTPUT (old)

% iter_output(count,:) = [dM_wing(1,mu) dM_tail(1,mu) dM_act(1,mu) dM_fuel(1,mu) dMTOW_guess(1,mu)];
% 
% filename = 'Iteration Data R2.xlsx';
% headings = {'Iteration Data'};
% % results = [dM_wing;dM_tail;dM_act;dM_fuel;dMTOW_guess];
% writecell(headings,filename,'Sheet',mu,'Range','C2');
% writematrix(iter_output,filename,'Sheet',mu,'Range','D2');
% 
% count = count+1;                        % WHILE-LOOP ITERATION COUNTER
% 
%     end                % WHILE LOOP ENDS
% 
% count                  % NUMBER OF ITERATIONS TAKEN TO CONVERGE ON MTOW_GUESS
% 
% end                    % FOR LOOP END

%% fresh attemp sept 17 (invalid now)

% Mwing(1)=Wing_Mass_Module_R2(WTO0,b(1), cr,ct0);
% 
% [ct_t,b_t,Lift_tail] = Tail_Resizing_ModuleTP_R4(WTO0,height,v_cr, Static_Margin, b,cr,ct0, b_t0,cr_t,ct_t0, HTVC0);
% Tail_Loads_set(1) = Lift_tail(1)/cos(D_a);                            % Convert lift to spanwise loading
% Mtail(1) = Wing_Mass_Module_R2(Tail_Loads_set(1),b_t(1), cr_t,ct_t0);
% S_tail = 0.5*(cr_t+ct_t).*b_t;

%% find new masses based on area density (invalid now)
% 
% wing_ad = Mwing(1)/Sref(1);
% tail_ad = Mtail(1)/S_tail(1);
% 
% for mu=2:size(b,2)
% Mwing(mu) = wing_ad.*Sref(mu);
% Mtail(mu) = tail_ad.*S_tail(mu);
% end

% %% ACTUATOR MASS / SPACE FOR MORPHED CONFIG
% M_ext(1)=0;
% for mu = 2:size(b,2)
% M_ext(mu) = Mwing(mu) .* 0.5.*(Sref(mu)-Sref(1))./Sref(mu);     % Approximate mass of extension, kg
% end 
% 
% Fric_coeff = 0.3;                               % Static friction coefficient
% acc_ext = 2.5;                                  % Acceleration, m/s2
% F_ext = M_ext*9.81*Fric_coeff + M_ext.*acc_ext;
% 
% M_act(1) = 0;
% space_act(1) = 0;
% m_fuel_lost(1) = 0;
% 
% for mu = 2:size(b,2)
% F = F_ext(mu);
% l = 1000*0.5*(b(mu)-b(1));
% 
% selected_actuator = FINDACT_r2(F,l,0);
% M_act(mu) = selected_actuator(1,4);
% 
% space_act(mu) = selected_actuator(1,5)/1000;
% 
% Mass_fudge = 1.20;                  % 20 % installation mass extra
% Space_fudge = 1.20;                 % 20 % installation space extra
% 
% M_act(mu) = (M_act(mu)*2)*Mass_fudge;
% space_act(mu) = Space_fudge*space_act(mu);
% 
% if space_act < 0.5*(b(mu)-b(1))
%     space_act(mu) = 0.5*(b(mu)-b(1));
% end
% 
% % FUEL LOST FOR MORPHED CONFIG
% 
% omega = 0.5;                                    % chordwise % of wing-box chord, refer to wing mass module
% 
% Fuel_density = 780;
% 
% m_fuel_lost(mu) = Fuel_density*omega*space_act(mu)*0.5.*(ct(1)-ct(mu));
% 
% end

% %% find new mtow
% 
% dM_wing = Mwing-Mwing(1);
% dM_tail = Mtail-Mtail(1);
% dM_act = M_act-M_act(1);
% dM_fuel = m_fuel_lost;
% 
% dMTOW_guess = dM_wing + dM_tail + dM_act - dM_fuel;
% % MTOW(2,:) = WTO0 + dMTOW_guess(2,:);


%% MORPHING SIZING
% temp3 = diff(Mwing);
% temp4 = diff(Mtail);
% temp5 = diff(M_act);

temp3 = Mwing - temp1;
temp3 = temp3(2:end);
temp4 = Mtail - temp2;
temp4 = temp4(2:end);
temp5 = M_act(2:end);


dM_wing = [0 temp3];
dM_tail = [0 temp4];
dM_act = [0 temp5];


EW_new = EW0 +dM_wing + dM_tail + dM_act;
EW_new = EW_new(2:end);

dM_fuel(2:end) = m_fuel_lost(2:end);
Mfuel = Mfuel0 - dM_fuel;
Mtail = -2*Mtail;

% MTOW_new = WTO0+dMTOW_guess(2:end);
MTOW_new = MTOW_guess(2:end);          % mastercode 15

b_new = b(2:end);
Sref_new = Sref(2:end);


[E]=Endurance_Morphing_R2(b_new, Sref_new, MTOW_new, EW_new,increase);

Eset = [24 E]


WTOset(1) = WTO0;
WTOset = [WTOset MTOW_new];

EWset = [EW0 EW_new]
EWFset = EWset./WTOset;


% dMTOW_guess=dMTOW_guess(2:end)
results = [b;Sref;WTOset;EWset;EWFset;Eset;Mwing;dM_wing;Mtail;dM_tail;M_act;dM_act;Mfuel;dM_fuel;F;l]; % added in mastercode 20
results = transpose (results);

filename = 'Morphing_Results_R7_10.xlsx';
% headings = {'RESULTS OF SPAN MORPHING (MASTERCODE19)';'Span (m)';'Reference Area (sq.m.)';'MTOW (kg)';'Empty Weight (kg)';'Empty Weight Fraction';'Endurance (hrs)';'Increase in MTOW (kg)';'Wing Mass (kg)';'Increase in Wing Mass (kg)';'Tail Mass (kg)';'Increase in Tail Mass (kg)';'Mass of Actuator (kg)';'Increase in Mass of Actuator (kg)';'Mass of fuel (kg)';'Decrease in mass of fuel (kg)'};
headings = {'RESULTS OF SPAN MORPHING (MASTERCODE20)','Span (m)','Reference Area (sq.m.)','MTOW (kg)','Empty Weight (kg)','Empty Weight Fraction','Endurance (hrs)','Wing Mass (kg)','Increase in Wing Mass (kg)','Tail Mass (kg)','Increase in Tail Mass (kg)','Mass of Actuator (kg)','Increase in Mass of Actuator (kg)','Mass of fuel (kg)','Decrease in mass of fuel (kg)','Force (N)','Stroke (m)'};


writecell(headings,filename,'Sheet',1,'Range','B1');
writematrix(results,filename,'Sheet',1,'Range','C2');
writematrix(d,filename,'Sheet',1,'Range','A1');


% headings2 = {'RESULTS OF SPAN MORPHING (MASTERCODE11)';'dM_wing';'dM_tail';'dM_act';'dM_fuel';'dMTOW_guess'};
% writecell(headings2,filename,'Sheet',2,'Range','C2');
% writematrix(iter_output,filename,'Sheet',2,'Range','D3');
% pause(inf)

%% PLOT RESIZED WINGS AND TAIL

figure(8)

wingposition = 5.072;

plotwings(cr, ct0, b, wingposition);
hold on

tailposition = wingposition+C_C;

plotwings(cr_t,ct_t0,b_t,tailposition)


% MORPHED AIRCRAFT : CD0 ESTIMATION

[CD0, k] = Drag_Module_R3(b,increase);

%% CONSTRAINT ANALYSIS CHECK

T = 38100/9.81;
% T = 34100/9.81;

% soln = CA_check_R1(WTOset(1),Sref(1),T,CD0(1),k(1),1);  % Dummy check values

% pause(inf)

for i=1:size(E,2)
X = [' Design Point for Span ',num2str(b(i+1)), ' m'];
disp(X)
soln = CA_check_R1(WTOset(i),Sref(i),T,CD0(i),k(i),i);  % Dummy check values
end
