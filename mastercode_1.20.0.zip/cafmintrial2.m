% fun = caobjecfun1;

global AA BB CC DD;
% -------
% Aerodynamic Input

ip(1) = 0.021;              % CD0
ip(2) = 0.175;              % k
ip(3) = 0.87;               % Wing efficiency
ip(4) = 24;                 % Aspect Ratio
ip(5) = 1.434;              % CLmax
ip(6) = 1;                  % CL_design
ip(7) = 1.434;                  % CL_takeoff, NOTE
ip(8) = 1.434;                  % CL_landing

% ------
% Mission Parameters
% ------

% Warmup and Take-off
ip(9) = 0.995;              % Warmup and Take-off Weight Fraction
ip(10) = 1;                 % Design weight Fraction beta
ip(11) = 1;                 % Thrust lapse ratio alpha
ip(12) = 1070;              % Takeoff distance, metres
ip(13) = 0;                 % Takeoff altitude, metres

% Climb
ip(14) = 0.985;             % Climb Weight Fraction
ip(15) = 7.5;                % Rate of Climb, m/s
ip(16) = 195;               % Forward speed in climb, m/s
ip(17) = 1;                 % Design weight Fraction beta
ip(18) = 1;                 % Thrust lapse ratio alpha
ip(76) = 0;             % Cruise height, metres
t1=ip(76);                  % temp height variable
[ip(77), ip(78),ip(79)] = atmosphere (t1,0); % temp, density, speed of sound

% Landing
ip(19) = 0.97;              % Landing Weight Fraction
ip(20) = 1;                 % Design weight Fraction beta
ip(21) = 1;                 % Thrust lapse ratio alpha
ip(22) = 1070;              % Landing distance, metres
ip(23) = 0;                 % Landing altitude, metres
t1=ip(23);                  % temp height variable
[ip(80), ip(81),ip(82)] = atmosphere (t1,0); % temp, density, speed of sound
ip(24) = 0.5;               % Coefficient of friction

% Cruise
ip(25) = 0.65;              % Maximum Mach Number
ip(26) = 15200;             % Height for Max. Mach No., metres
ip(27) = 15200;             % Cruise height, metres
t1=ip(27);                  % temp height variable
[ip(28), ip(29),ip(30)] = atmosphere (t1,0); % temp, density, speed of sound
ip(31) = ip(25)* ip(30);    % speed, m/s
ip(32) = 1;                 % Design weight fraction beta
ip(33) = 1;                 % Thrust lapse ratio alpha
ip(34) = 0.866*ip(6);       % Cruise CL, NOTE
ip(35) = 0.5*ip(29)*ip(31)^2;   % Dynamic pressure in cruise, Pa

% Loiter
ip(36) = 0.65;              % Maximum Mach Number
ip(37) = 15200;             % Cruise height, metres
t1=ip(37);                  % temp height variable
[ip(38), ip(39),ip(40)] = atmosphere (t1,0); % temp, density, speed of sound
ip(41) = ip(36)* ip(40);    % Loiter speed, m/s
ip(42) = 1;                 % Design weight fraction beta
ip(43) = 1;                 % Thrust lapse ratio alpha
ip(44) = 0.5*ip(39)*ip(41)^2;   % Dynamic pressure in loiter, Pa

% Instantaneous Turn Rate
ip(45) = 10;                 % Instantaneous turn rate, degrees per second
ip(46) = ip(45)*pi()/180;   % Instantaneous turn rate, radians per second
ip(47) = 0.35;               % Turn forward speed Mach Number
ip(48) = 5500;              % Instantaneous turn design altitude, metres
t1=ip(48);                  % temp height variable
[ip(49), ip(50),ip(51)] = atmosphere (t1,0); % temp, density, speed of sound
ip(52) = ip(47)* ip(51);    % Forward speed, m/s
ip(53) = 0.8288;              % Design weight fraction beta, NOTE
ip(54) = 0.8;                 % Thrust lapse ratio alpha
ip(55) = 1;                 % Turn CL, NOTE
ip(56) = 0.5*ip(50)*ip(52)^2;   % Dynamic pressure in instantaneous turn, Pa
ip(57) = sqrt(1+(ip(46)*ip(52)/9.807)^2);   % Vertical load factor in turn, NOTE

% Sustained Turn
ip(58) = 2;                 % Sustained turn vertical load factor
ip(59) = 0.4;               % Turn forward speed Mach Number
ip(60) = 0;                 % Instantaneous turn design altitude, metres
t1=ip(60);                  % temp height variable
[ip(61), ip(62),ip(63)] = atmosphere (t1,0); % temp, density, speed of sound
ip(64) = ip(59)* ip(63);    % Forward speed, m/s
ip(65) = 1;                 % Design weight fraction beta
ip(66) = 1;                 % Thrust lapse ratio alpha
ip(67) = 0.5*ip(62)*ip(64)^2;   % Dynamic pressure in sustained turn, Pa
ip(68) = 2;                 % Vertical load factor in turn

% Stall
ip(69) = 64;               % Stall speed, m/s
ip(70) = 0;                 % Stall design altitude, metres
t1=ip(70);                  % temp height variable
[ip(71), ip(72),ip(73)] = atmosphere (t1,0); % temp, density, speed of sound
ip(74) = 0.5*ip(72)*ip(69)^2;   % Dynamic pressure in stall, Pa
ip(75) = 1.66;              % Stall CL, NOTE

%%%%%%%%%%%%%%%%%%%%%%%%%

% Take-off distance
AA(1) = 0;
BB(1) = 0;
CC(1) = 0;
DD(1) = 1.44/(ip(81)*ip(7)*ip(12)*9.807);

% Climb rate
AA(2) = 0.5*ip(78)*ip(16)*ip(16)*ip(1)/(9.801*ip(18));
BB(2) = ip(2)*ip(17)^2*9.807/(ip(18)*0.5*ip(78)*ip(16)*ip(16));
CC(2) = ip(17)*ip(15)/(ip(18)*ip(16));
DD(2) = 0;

% Landing
AA(3) = 0;
BB(3) = 0;
CC(3) = 0;
DD(3) = ip(22)*ip(81)*ip(8)*ip(24)/(1.69*ip(20));

% Maximum Mach Number


AA(4) = 0.5*ip(29)*ip(31)*ip(31)*ip(1)/(9.801*ip(33));
BB(4) = ip(2)*ip(32)^2*9.807/(ip(33)*0.5*ip(29)*ip(31)*ip(31));
CC(4) = 0;
DD(4) = 0;

% Instantaneous Turn Rate

AA(5) = 0;
BB(5) = 0;
CC(5) = 0;
DD(5) = ip(56)*ip(55)/(9.807*ip(57)*ip(53));

% Sustained Turn

AA(6) = 0.5*ip(62)*ip(64)*ip(64)*ip(1)/(9.801*ip(66));
BB(6) = ip(2)*ip(65)^2*9.807*ip(58)^2/(ip(66)*0.5*ip(62)*ip(64)*ip(64));
CC(6) = 0;
DD(6) = 0;

% Stall

AA(7) = 0;
BB(7) = 0;
CC(7) = 0;
DD(7) = ip(74)*ip(75)/9.807;

lb = [DD(5),0];
ub = [DD(7),1];
A = [-DD(1) 1];
b = [0];
Aeq = [];
beq = [];
x0 = [200,0.2];
%nonlcon = @nonlconstr1;
options = optimoptions('fmincon','Display','iter','Algorithm','sqp');
x = fmincon(@caobjecfun2,x0,A,b,Aeq,beq,lb,ub,@canonlconstr1, options)
%za = meshgrid(-2:.2:2);
%zb = meshgrid(-2:.2:2);
%zc = 100*(zb-za^2)^2 + (1-za)^2;
%surf(zc,za,zb)

syms x y

yy (x,y) = AA(2) + BB(2)*x.^2 + CC(2)*x - x.*y;
% ezplot(yy);
fig2 = ezplot(yy,[0,1000,0.1,0.5]);
set(fig2,'color','black','LineWidth',2);
M2 = 'Climb Rate';

hold on

yy (x,y) = DD(1);
% ezplot(yy);
fig1 = ezplot(yy,[0,1000,-.1,0.5]);
set(fig1,'color','red','LineWidth',2);
M1 = 'Take-off Distance';

hold on

% ezplot(yy);
yy (x,y) = AA(4) + BB(4)*x.^2 + CC(4)*x - x.*y;
fig4=ezplot(yy,[0,1000,0.1,0.5]);
set(fig4,'color','blue','LineWidth',2);
M4 = 'Maximum Mach Number';

hold on

yy (x,y) = x-DD(5);
% ezplot(yy);
fig5=ezplot(yy,[0,1000,-.1,0.5]);
set(fig5,'color','cyan','LineWidth',2);
M5 = 'Instantaneous Turn';

hold on

% ezplot(yy);
yy (x,y) = AA(6) + BB(6)*x.^2 + CC(6)*x - x.*y;
fig6=ezplot(yy,[0,1000,0.1,0.5]);
set(fig6,'color','magenta','LineWidth',2);
M6 = 'Sustained Turn';

hold on

yy (x,y) = x-DD(7);
% ezplot(yy);
fig7=ezplot(yy,[0,1000,-.1,0.5]);
set(fig7,'color','green','LineWidth',2);
M7 = 'Stall';

grid on
grid minor
title('Constraint Analysis');
legend([fig1, fig2, fig4, fig5, fig6, fig7], M1, M2, M4, M5, M6, M7);

% syms x y
% yy (x,y) = AA(4) + BB(4)*x.^2 + CC(4)*x - x.*y;
% fig = ezplot(yy,[0,1000,0.1,0.5]);
% 
% yy1 = @(x,y) AA(6) + BB(6)*x.^2 + CC(6)*x - x.*y;
% yy2 = @(x,y) AA(2) + BB(2)*x.^2 + CC(2)*x - x.*y;
% 
