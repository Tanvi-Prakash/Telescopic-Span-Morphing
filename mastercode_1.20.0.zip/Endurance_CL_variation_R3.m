function[WTO, EW, MF,CL_cr, CD_cr]=Endurance_CL_variation_R3(E,increase)
% __________ L/D estimation ___________

% CD0 = 0.015;                     % Insert value from drag estimation module
% k = 0.0135;                      % Insert value from drag estimation module
% E = 24;                        % Target Endurance, hours
% E = [24,25,26,27,28];            % Target Endurance, hours

%% Initial Values

Mpayload = 907;                         % Payload mass, kg, RQ4-A

MTOW_guess = 10000;                     % Guess MTOW, kg, RQ4-A
% Mfuel = 4680;                         % Guess Fuel weight, kg, RQ4-A
reserve = 0;                            % Reserve fuel percentage, assumption

S = 51.019;                               % Wing reference area, sq.m.
b = 35.42;                              % Wing span, m

% b = 44.2;
% S = 55.31;

% v_cr = 192*1.15;                             % Cruise speed, m/s
v_cr = 192;


rho = 0.115;    % 60,000 feet
% rho = 0.1694; % 52,000 feet
% rho = 0.6527; %20,000 feet
% rho = 1.225;  % MSL

error_MTOW = 100;

%% Target Values

% E = 24;

%% Iterations

% [CD0, k] = Drag_Module_R2(b);
[CD0, k] = Drag_Module_R3(b,increase);

while (abs(error_MTOW) > 1)

    if error_MTOW < 0
        MTOW_guess = MTOW_guess + 10;
    else MTOW_guess = MTOW_guess - 10;
    end

CL_loit = MTOW_guess * 9.81 * 0.936 / (0.5 * rho * v_cr*v_cr * S);  % WF at start of loiter = 0.936
CD_loit = CD0 + (k * CL_loit*CL_loit);

LbyD_loit = CL_loit./CD_loit;

% file 2a

% LbyD_cr = 0.866*LbyD_loit;          % Minimum power cruise L/D
% 
% p=[k.*LbyD_cr -1 LbyD_cr.*CD0];
% 
% CL_cr = min(roots(p));
% CD_cr = CL_cr/LbyD_cr;

% file 2

CL_cr = MTOW_guess * 9.81 * 0.92 / (0.5 * rho * v_cr*v_cr * S);  % WF at end of climb = 0.92
CD_cr = CD0 + (k * CL_cr*CL_cr);

LbyD_cr = CL_cr./CD_cr


%% ___________ Weight Fraction Estimations ___________

% EWF = (MTOW-Mfuel-Mpayload)/MTOW
% EWF = 0.5385;
% EWF = -0.0043*E + 0.6392;
EWF = 2.43*(MTOW_guess^-0.16);              % Raymer, 5th edition, High altitude aircraft
% EWF = 0.3594;
% EWF = 2.6*((0.453592*MTOW)^(0.815-1));  % Nicolai, Appendix i

c_cr = 0.0001667;                       % SFC cruise in kg/kg-s
c_loit = c_cr/1.25;                     % SFC loiter in kg/kg-s  < why same sfc?

Range = 1200*1853;                      % Range in m, 1200 nautical miles
WF_loit = exp(-Range*c_cr./(v_cr.*LbyD_cr));

WF_takeoff = 0.995;
WF_climb = 0.985;
WF_landing = 0.97;

Endurance = E.*3600;                    % Endurance in seconds

WF_endurance = exp(-c_loit.*Endurance./(LbyD_loit));

MWF = WF_takeoff*WF_climb.*WF_loit.*WF_loit*WF_landing.*WF_endurance;


WTO = Mpayload./(1-EWF-(1+reserve/100)*(1.-MWF));
EW = EWF*WTO;
MF = (1-MWF).*WTO;

error_MTOW = (MTOW_guess-WTO)*100/MTOW_guess;
end

filename = 'CL CL Results.xlsx';
headings = {'Span';'Ref Area';'CL_cr';'CD_cr';'LbyD_cr';'CD0';'k';'CD_cr-CD0';'CD_cr.Sref';'q'};
results = [b; S; CL_cr; CD_cr; LbyD_cr; CD0; k; CD_cr-CD0; CD_cr*S; 34100/(CD_cr*S*9.81)];
writecell(headings,filename,'Sheet','2','Range','C2');
writematrix(results,filename,'Sheet','2','Range','D2');
end

% CHECKS

% Wempty = EWF.*WTO;
% WFuel = (1+reserve/100)*(1-MWF).*WTO;
% Ratiofuel = WFuel(2:end)./WFuel(1);
% increase = Ratiofuel*0.6628;                    % check ratio < size of fuel tank original
