% E = [24];
% b = [35.42];

% E = [24,25,26,27,28]

% Baseline Aircraft
clear all
clc

E = 24;
b = 35.42;

% WTOset = zeros(1,6);

[WTO0, EW0, MW0] = Endurance_CL_variation_R1(E)

b = [35.42, 37, 39, 40, 41];
[CD0, k] = Drag_Module_R2(b);


cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m
ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);                  

T = 34100/9.81;



% bset=sqrt(Sset.*25);
% bsetby2 = bset/2;
%         
% cr = (Sset./bset) + (0.25*bset*tan(5*pi/180));  % height 
% ct = cr- (0.5*tan(5*pi/180).*bset);

% a = 2 ;  % top side
% b = 4 ;   % base 
% %%Frame vertices
% A = [0 0] ;
% B = [bsetby2 0] ;
% C = [bsetby2 ct] ;
% D = [0 cr] ;  
% coor = [A ; B; C; D] ;  
% patch(coor(:,1), coor(:,2),'r')

% figure(2);
% for i=1:7
% hold on
% fig = plot([0 bsetby2(i)],[cr(i) ct(i)]);
% hold on
% 'check';
% end

figure(8)

wingposition = 5.671;

plotwings(cr, ct, b, wingposition);
hold on

cr_tail = 1;
ct_tail = 0.5;
b_tail = 6;
tailposition = 9;

plotwings(cr_tail,ct_tail,b_tail,tailposition)

% Actuator Mass Section

% M_act = 100;

F_act = 3750;
l_act = 8000;

selected_actuator = FINDACT_r1(F_act, l_act,1);
M_act = selected_actuator(4);
space_act = selected_actuator(5);

% Wing Mass Section

[Mwing]=Wing_Mass_Module_R2(WTO0,b, cr,ct0);
del_Mwing = Mwing(2:end)- Mwing(1);


% Tail Loads Section

Tail_Loads_set = [2300,2400,2500,2600,2700]; % to be refined

% Tail Mass Section

[Mtail]=Wing_Mass_Module_R2(Tail_Loads_set,b_tail, cr_tail,ct_tail);
del_Mtail = Mtail(2:end)-Mtail(1);

% New Weights Section

% size(EW0)
% size(del_Mwing)
% size(del_Mtail)
% size(M_act)

EW_new = EW0 + del_Mwing + del_Mtail + M_act
MTOW_new = WTO0+(EW_new-EW0)
b_new = b(2:end)
Sref_new = Sref(2:end);

[E]=Endurance_Morphing_R0(b_new, Sref_new, MTOW_new, EW_new)

WTOset(1) = WTO0;
WTOset = [WTOset MTOW_new];

WTOset

for i=1:size(E,2)
soln = CA_check_R1(WTOset(i),Sref(i),T,CD0(i),k(i),i);  % Dummy check values
end
