function f = caobjecfun2(x)
f = x(2);