function [output_findact] = FINDACT_r4(x,y,n)
% clear all

% x = force
% y = stroke
% n = 0 for minimum mass, 1 for force-based ballparking
% x
% y

% R4: force based and stroke based ballparking rewritten afresh

% 
% load input.mat

% load hyd.mat
% load pneum.mat
% load elec.mat

load combine.mat

%% -------- Test variable selection ------- %

% choice = 3;
% value  = 5000;
% 
% % choice = 2;
% value = 2000;
% 
% choice = 1;
% value = 2;
%% SAMPLE INPUT DATA

% reqd = [3750,8000];
% n=1;

%% READ INPUT DATA

if x ==0 || y==0
    output_findact=zeros(6);
    return
end

reqd = [x,y];

%% ----- SORT DATA COMBINE ----- %

% section replaces idhyd matrix with ID HYD = 1, PNEUM = 2, ELEC = 3

idhyd = ones(size(nhyd,1),1);
idpneum = 2*ones(size(npneum,1),1);
idelec = 3*ones(size(dummy,1),1);

combine =[nhyd shyd fhyd mhyd lhyd idhyd;
    npneum spneum fpneum mpneum lpneum idpneum;
    dummy selec felec melec lelec idelec];
% combine(:,6)=1:size(combine);           % assign serial numbers in last column
combine = sortrows(combine,2) ;         % sort by stroke

%% --- find solutions that provide stroke ---
ans1 = find(combine(:,2)>reqd(2));
cand1 = combine(ans1,:);

% --- find solutions that provide force ---
ans2 = find(cand1(:,3)>reqd(1));
cand2 = cand1(ans2,:);

%% n=0

if n==0
% --- find mimimum mass --- CHECK AS IT DOESNT FIND MINUMUM STAGES
[mini, i] = min(cand2(:,4));
selected = cand2(i,:);

% c2=clock;

% if(selected(6)<(size(nhyd,1)+1))
%     fprintf('Hydraulic No. %d .\n', selected(6))
% else if (selected(6)<(size(nhyd,1)+size(npneum,1)+1))
%         fprintf('Pneumatic No. %d .\n', selected(6))
%     else fprintf('Electrical No. %d .\n', selected(6))
%     end
% end

end
%% Force Based Ballparking

if n==1
  % 'Force-based Ballparking'                 % IMP, force & stroke are 'reversed here

  % New Section June 2023

cand3 = sortrows(cand1,3);

ans2 = find(cand3(:,3)>reqd(1));            % Force criteria applied

cand4 = cand3(ans2(1),:);                   % ballpark end 2

if ans2(1) ==1
    cand5 = cand3(ans2(1),:);                % if ballpark end 1 = ballpark end 2
    ratio = 1;
else
cand5 = cand3((ans2(1)-1),:);                % ballpark end 1
ratio = (reqd(1)-cand5(3))/(cand4(3)-cand5(3)); % ballparking ratio

end


mass = ratio*(cand4(4)-cand5(4)) + cand5(4);    % ballparked mass
length = ratio*(cand4(5)-cand5(5)) + cand5(5);  % ballparked length
stroke = ratio*(cand4(2)-cand5(2)) + cand5(2);  % ballparked stroke
id = ratio*(cand4(6)-cand5(6)) + cand5(6);      % ballparked notional id
n = 10;

selected = [n stroke reqd(1) mass length id];   % no of stages is 0 as irrelevant now

end
%% Stroke Based Ballparking

if n==2
    'Stroke-based Ballparking'

ans1 = find(combine(:,2)>reqd(1));          % define cand11 for all members that meet force
cand11 = combine(ans1,:);

cand3 = sortrows(cand11,2);

ans2 = find(cand3(:,2)>reqd(2));            % Force criteria applied

cand4 = cand3(ans2(1),:);                   % ballpark end 2

if ans2(1) ==1
    cand5 = cand3(ans2(1),:);                % if ballpark end 1 = ballpark end 2
    ratio = 1;
else
cand5 = cand3((ans2(1)-1),:);                % ballpark end 1
ratio = (reqd(1)-cand5(2))/(cand4(2)-cand5(2)); % ballparking ratio

end

mass = ratio*(cand4(4)-cand5(4)) + cand5(4);    % ballparked mass
length = ratio*(cand4(5)-cand5(5)) + cand5(5);  % ballparked length
force = ratio*(cand4(3)-cand5(3)) + cand5(3);  % ballparked stroke
id = ratio*(cand4(6)-cand5(6)) + cand5(6);      % ballparked notional id
n = 20;

selected = [n reqd(2) reqd(1) mass length id];   % no of stages is 0 as irrelevant now



%% Rejected Code

  % ans2a = [cand1(size(cand1,1)-size(cand2,1)); ans2];   % only one lower value considered
  % cand2a = cand1(ans2a,:);                   % WRONG
  % 
  % s=sortrows(cand2a,4);                     % sort based only on mass, not space
  % 
  % diff=abs(cand2a(:,3)-reqd(2));
  % [minm,imin]= min(diff);
  % 
  % temp=sort(diff);
  % 
  % imin2=find(diff == temp(2));
  % i=[imin;imin2];
  % 
  % ballparkends=cand2a(i,:)
  % diff = ballparkends(:,3)-reqd(2);
  % % size(ballparkends);
%   ratio1=abs(diff./(ballparkends(1,3)-ballparkends(size(ballparkends,1),3)))
%   % sumz = sum(unique(ratio1))
%   ratio=unique(ratio1);
% 
% selected = [0 (ratio(1)*ballparkends(1,2)+ratio(2)*ballparkends(2,2)) (ratio(1)*ballparkends(1,3)+ratio(2)*ballparkends(2,3)) (ratio(1)*ballparkends(1,4)+ratio(2)*ballparkends(2,4)) (ratio(1)*ballparkends(1,5)+ratio(2)*ballparkends(2,5)) (ratio(1)*ballparkends(1,6)+ratio(2)*ballparkends(2,6))];

end
%% Collate output variable

output_findact = [selected];


end
% 

% end


