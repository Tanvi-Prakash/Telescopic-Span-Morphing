function f = caobjecfun1(x)
f = x(1);