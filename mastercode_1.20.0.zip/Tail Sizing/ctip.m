function [c_tip] = ctip(c_root, c_tip_initial, span_set)

% span_set
% c_root
% c_tip_initial

le_sweep = atan((c_root - c_tip_initial)./(0.5.*span_set(1)))
c_tip = c_root - (0.5.*tan(le_sweep).*span_set)

en