function [t rho a] = atmosphere(height,offset)
% syms t rho a;

tempzero = 288.160 + offset;


if (height < 11000)
t = tempzero - 0.0065 * height;
rhozero = 101325/(287 * tempzero);
rho = rhozero * (tempzero / t)^(-9.807/(0.0065*287)+1);

else t = 216.65;
    rhozero = 101325/(287 * tempzero);
rhocap = rhozero * (tempzero / t)^(-9.807/(0.0065*287)+1);
    rho = rhocap * exp(-(height - 11000) * 9.807/(287 * t))
end    
a = 20.05 * t^0.5;
end
