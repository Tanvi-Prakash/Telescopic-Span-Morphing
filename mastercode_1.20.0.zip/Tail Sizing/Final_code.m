% Distance between the horizontal tail aerodynamic center and the
% wing/fuselage aerodynamic center is l

C_C = 5.972;                    % Distance of the the tail root chord from the wing root chord
rc = 2.52;                      % Root Chord of the Wing
tc = 0.71;                      % Tip Chord of the wing
b = 35.4177;                    % Wing Span
fuselage_chord_wing = 2.12;     % root chord at fuselage
fuselage_width = 1.52; 
Tail_rc = 1.833;
Tail_tc = 0.71;
Tailspan = 4.598;               % Considering span to the meeting point of the root chords
fuselage_chord_tail = 1.53;
tail_span_exposed = 3.474;
Control_SA = 1.232304481;       % Along the slanted span
cl_alpha_LRN = 6.2698;          % 2D lift curve slope in radians
cl_alpha_NACA0012 = 6.1907;
% L_sweep = 0.122173022;         % Leading Edge Sweep
L_sweep = atan((rc-tc)/(0.5*b)); % Value is 5.98, this should be 7 degrees
Dihedral_Angle = 50;
Static_Margin = 15;             % Validate 
Tail_MAC = 2*(Tail_rc*Tail_rc + Tail_tc*Tail_tc + Tail_rc*Tail_tc)/(3*Tail_rc+3*Tail_tc);
Wing_MAC = 2*(rc*rc + tc*tc + rc*tc)/(3*rc+3*tc);
Tail_angle = 0.5*(180-Dihedral_Angle);
l = C_C-(rc - Wing_MAC)-0.25*Wing_MAC + (Tail_rc-Tail_MAC)+ 0.25*Tail_MAC;
D_a = 0.0174533*Dihedral_Angle*0.5;
T_a = 0.0174533*Tail_angle;
S_h = (Tail_rc+Tail_tc)*Tailspan*cos(T_a);
S_v = 0.5*(Tail_rc+Tail_tc)*Tailspan*cos(D_a);
% S_ref = 0.5*(fuselage_chord_wing+tc)*(b-0.5*fuselage_width);%Check if Sref is till the root chord, check Raymer and Nicolai
% S_ref = 0.5*(tc+rc)*b;
S_ref = 50;
HTVC = l*S_h/(Wing_MAC*S_ref);
VTVC = l*S_v/(S_ref*b);
actual_vtvc = 0.0186;
actual_htvc = 0.32;
htvc_dev = 100*(actual_htvc-HTVC)/actual_htvc;
vtvc_dev = 100*(actual_vtvc-VTVC)/actual_vtvc;
disp("The vertical Tail volume coefficent is: "), disp(VTVC);
disp("The deviation in % is: "), disp(vtvc_dev);
disp("The Horizontal Tail volume coefficent is: "), disp(HTVC);
disp("The deviation in % is: "), disp(htvc_dev);

Half_Tail_Area = S_h/(2*cos(1.13446)); % Half tail Area actual
Half_Tail_Area_Exposed = 0.5*(fuselage_chord_tail+Tail_tc)*tail_span_exposed; %Exposed half tail area
Area_ratio = Control_SA/Half_Tail_Area;
Tou = -4.3443*(Area_ratio^4) + 8.0198*(Area_ratio^3) - 5.9526*(Area_ratio^2) + 2.8361*Area_ratio + 0.0205;
%Cl_trim = 1.0679;              % Cl at trim condition of angle of 0.0960763 radian
AR = (b^2)/S_ref;
T_AR = 3;                       % HARD CODED
T = 1+tan(L_sweep)*tan(L_sweep);
O_E_wing = 2/(2-AR+sqrt(4+AR*AR*T));
k1 = 1/(pi*AR*O_E_wing);
Cl_alpha_W= cl_alpha_LRN/(1+k1*cl_alpha_LRN);

O_E_tail = 2/(2-T_AR+sqrt(4+T_AR*T_AR*T));
Cl_alpha_T = cl_alpha_NACA0012/(1+cl_alpha_NACA0012/(pi*O_E_tail*T_AR));
d_eps_alpha = 2*Cl_alpha_W/AR;
Cl_alpha_Aircraft = Cl_alpha_W+ Cl_alpha_T*(1-d_eps_alpha)*2*Half_Tail_Area/b;
Cl_alpha_Aircraft_0 = 0.491;    % Intercept value, hard coded

MTOW = 11611.965;               % in kg
density = 0.11532; 
Velocity = 191.815;
Cl_trim = MTOW*9.81/(0.5*density*Velocity*Velocity*S_ref); % Coefficient of trim at level flight with MTOW

Alpha_trim = (Cl_trim - Cl_alpha_Aircraft_0)/Cl_alpha_Aircraft;
Alpha_trim_d = Alpha_trim*57.2958;

%Alpha_trim = 4.12 degree

eta = 1;
C_m_delEps = -HTVC*eta*Cl_trim*Tou; % Elevator effectiveness Parametre
disp("The elevator effectiveness is given by:"), disp(C_m_delEps);

Cm_alpha = -Cl_alpha_W*Static_Margin/100;
Cm_0 = -0.5069;                     % y-intercept HARD CODED
%delta_trim = -(Cm_o*Cl_alpha_T + Cm_alpha_slope*Cl_trim)/(C_m_delEps*Cl_alpha_T - Cm_alpha*Cl_deltaE);
delta_trim1 = -(Cm_0 + Cm_alpha*Alpha_trim)/C_m_delEps;
disp("Elevator Trim angle is:"), disp(delta_trim1);

Cm_Alpha_F = 0.564936221;           % Assuming the root chord nose to be the reference point

X_AC = rc - Wing_MAC + 0.25*Wing_MAC;
X_NP = X_AC - Wing_MAC*(Cm_Alpha_F/Cl_alpha_W) + Wing_MAC*eta*HTVC*(1-d_eps_alpha)*Cl_alpha_T/Cl_alpha_W
X_CG = X_NP-Static_Margin*Wing_MAC/100
%disp(Cm_alpha);