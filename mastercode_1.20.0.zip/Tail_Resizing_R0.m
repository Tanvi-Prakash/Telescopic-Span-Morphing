function[lt, ctt, crt]=Tail_Resizing_R0(WTO,b,bt,crt,ct0t,lt0,cr0,ct0)

% NOTE: bt is along the span of the wing, i.e. along the cant angle

cant = 40*pi/180;                      % radians, tail cant angle to vertical
ctt = ctip(crt, ct0t, bt);

ct = ctip(cr0, ct0, b);

bt0 = bt(1);
bt_y(1) = bt0 * sin(cant);
bt_z(1) = bt0 * cos(cant);

Sref = 0.5*(cr0+ct).*b
S_ht = 0.5*(crt+ctt).*bt_y
S_vt = 0.5*(crt+ctt).*bt_z;

lambda = ct./cr0;
lambdat = ctt/crt;

%MAC Wing
mac = 2*cr0.*(1+lambda+(lambda.^2))./(3.*(1+lambda))


%MAC Tail
mact = (2*crt.*(1+lambdat+(lambdat.^2)))./(3*(1+lambdat));                         % (Nicolai, Fig 2.1) 


lt=zeros(1,size(mac,2));
lt(1) = lt0;
bt(1) = bt0;

for i = 2:(size(mac,2))
    lt(i) = lt0 + 0.25*(mact(i)-mact(1)) + 0.25*(mac(i) - mac(1))
end

TVC_H = lt.*S_ht./(Sref.*mac) % lt ~ cr,lambda, crt, lambdat; S_ht ~ crt, bt, ctt; mac ~ cr
TVC_V = lt.*S_vt./(Sref.*b)
end
