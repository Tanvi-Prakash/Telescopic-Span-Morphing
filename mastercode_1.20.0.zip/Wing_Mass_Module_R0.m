% function[Mwing]=Wing_Mass_Module_R0(WTO,b)
clear all
clc

cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m
b = 35.42;                              % Wingspan, m

WTO = 12134;


% Computed cases for Span extension
% b = [35.42,36,37,38,39,40];
ct = ctip(cr, ct0, b);

Mwing = 10;
Mwing0 = 0;

rh = 0.75; % box depth ratio

    Sref = 50.6994;  % wing reference area
    Sref = 50.2;
    Sref = 0.5.*(cr+ct)*b;
    
    AR = 24.7412; % aspect ratio
    AR = 35.42*35.42/52.2;
    AR = b.*b./Sref;
    
%     CL = 1;
%     dyn_press = 0.5*0.0841*200*200; % 20000 m altitude
%     
%     cr = 2.178;             % metre
%     cr = 2.258;
%     
%     ct = 0.685;
    lambda = ct/cr;         % ct/cr
    Nlift = 2.5;
    FoS = 1.25;
    ultimatestrength = 572000000/FoS;
    shearstrength = 331000000/FoS;
    tau = 0.152;            % (tbyc)
    omega = 0.5;
    rho = 2700;             % Density, (kg/cubic metre)
    
while (abs(Mwing-Mwing0)>5)   
    
    Mwing0 = Mwing;
    Ldash = (WTO-Mwing0)*9.81;   % upward force on wing, N
    
    bendingmoment = (Ldash*AR*cr*(1+(2*lambda)))/24;
    Icap_bar = (Nlift*bendingmoment*tau)/(2*cr*cr*cr*ultimatestrength);
    s = roots([(0.92*omega*tau),(-0.92*0.92*omega*tau*tau*0.5),(Icap_bar)]);
    
%     disp('The first root is: '), disp(s(1));
%     disp('The second root is: '), disp(s(2));

    s1 = s(1);
    s2 = s(2);
    if s1<s2
        root = s1;
    else 
        root = s2;
    end
   
    tcaproot = root*cr;
    tweb_bar = (AR*Nlift*Ldash*(1+(2*lambda)+(lambda*lambda)))/(12*tau*Sref*shearstrength);
    twebroot = tweb_bar*cr;
    Wcap = 0.85*(8*rho*9.81*omega*root*(Sref^1.5)*((lambda^2)+lambda+1))/(3*(AR^0.5)*((1+lambda)^2));
    Wweb = 0.85*(8*rho*9.81*rh*tau*tweb_bar*(Sref^1.5)*((lambda^2)+lambda+1))/(3*(AR^0.5)*((1+lambda)^2));
    Mwing = 2*(Wcap + Wweb)/9.81;
   
        Mwing= Mwing-5;
   
end

fprintf('Wing mass is %d kg\n',Mwing)
fprintf('Spar thickness at root is %d mm\n',tcaproot*1000)
fprintf('Skin thickness at root mass is %d mm\n',twebroot*1000)

% Error_wing_percent = (1138-Mwing)*100/1138
% end