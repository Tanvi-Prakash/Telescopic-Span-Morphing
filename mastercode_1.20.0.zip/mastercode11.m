clear all
clc

%% INPUT

% BASELINE AIRCRAFT PARAMETERS

E = 24;
b = 35.42;

height = 18300;
v_cr = 192;

Static_Margin = 25;

% GEOMETRY INPUT - WING

cr = 2.203;                             % Root chord, m
ct0 = 0.6778;                            % Tip chord, m

% GEOMETRY INPUT - TAIL
C_C = 5.972;                    % Distance bet noses of tail root chord and wing root chord, m
cr_t = 1.53;                    % Variable name changed!
ct_t0 = 0.71;                   % Initial tail tip chord, m
% cr_t = 1.833;                 % Tail root chord at centreline, m
b_t0 = 6.948;                   % Initial tail span, m 3.474*2

% AIRCRAFT INITIAL SIZING: BASELINE
[WTO0, EW0, MW0] = Endurance_CL_variation_R2(E);

ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);  
Wing_MAC0 = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% TAIL - INITIAL SIZING: BASELINE

Tail_MAC0 = 2*(cr_t*cr_t + ct_t0*ct_t0 + cr_t*ct_t0)/(3*cr_t+3*ct_t0);
l0 = C_C-(cr - Wing_MAC0)-0.25*Wing_MAC0 + (cr_t-Tail_MAC0)+ 0.25*Tail_MAC0;
Dihedral_Angle = 50;          % Tail dihedral, degrees
D_a = pi()/180 * Dihedral_Angle;
S_h0 = (cr_t + ct_t0) * 0.5*b_t0 * cos(D_a);

HTVC0 = l0 * S_h0/(Wing_MAC0*Sref);

%% Original Weights Section

Mpayload = 907;
Mfuel0 = WTO0 - EW0 - Mpayload
EW0
WTO0

%% MORPHED AIRCRAFT DEFINITION

% b = [35.42, 36, 36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40, 40.5, 41,41.5, 42,42.5,43,43.5,44,44.2];

b = [35.42, 36, 37, 38, 39, 40, 41, 42,43,44,44.2];

% b=35.42;


% MORPHED AIRCRAFT : CD0 ESTIMATION

[CD0, k] = Drag_Module_R2(b);

% MORPHED AIRCRAFT WING GEOMETRY DEFINITION

ct = ctip(cr, ct0, b);
Sref = 0.5.*b.*(cr+ct);  
Wing_MAC = 2*(cr.*cr + ct0.*ct0 + cr.*ct0)./(3*cr+3*ct0);

% pause(inf)

%% ITERATE MTOW OF MORPHED CONFIG TO GET MORPHED WING, TAIL, ACTUATOR MASS

dM_wing = zeros(1,size(b,2));
dM_tail = zeros(1,size(b,2));
dM_act = zeros(1,size(b,2));
dM_fuel = zeros(1,size(b,2));
% dMTOW_guess = zeros(1,size(b,2));
M_act = zeros(1,size(b,2));
space_act = zeros(1,size(b,2));
F_ext = zeros(1,size(b,2));
m_fuel_lost = zeros(1,size(b,2));
Mwing = zeros(1,size(b,2));
Mtail = zeros(1,size(b,2));
ct_t = zeros(1,size(b,2));
b_t = zeros(1,size(b,2));
Lift_tail = zeros(1,size(b,2));
Tail_Loads_set = zeros(1,size(b,2));
M_ext = zeros(1,size(b,2));

% dMTOW_guess = [2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000];
% MTOW_guess = [WTO0 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000];

% dMTOW_guess = [2000 2000 2000 2000 2000 2000 2000 2000 2000 2000 2000];
size(b,2);
dMTOW_guess =  2000 * (ones(1,size(b,2)));

% MTOW_guess = [WTO0 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000 13000];
MTOW_guess = [WTO0 15000*ones(1,size(b,2))];

%% (OUTER) FOR LOOP: TAKING ONE MORPHED SPAN AT A TIME

for mu = 2:size(b,2)                % mu = index of each new span
mu;                                 % Morphed span number
count = 1;                          % Reset While-Loop Iteration counter

%% (INNER) WHILE LOOP: TO ARRIVE AT MTOW FOR THIS SPAN

    while ((dMTOW_guess(mu) - abs(MTOW_guess(mu)-WTO0))>5)
mu*2;
count;
%% CHOOSING A GUESS MTOW

    if dMTOW_guess(mu) > MTOW_guess(mu) - WTO0
        MTOW_guess(mu) = MTOW_guess(mu)-10;
    end

    if dMTOW_guess(mu) < MTOW_guess(mu) - WTO0
        MTOW_guess(mu) = MTOW_guess(mu)+10;
    end

%% WING MASS FOR MORPHED CONFIG

Mwing(mu)=Wing_Mass_Module_R2(MTOW_guess(mu),b(mu), cr,ct0);

%% TAIL MASS FOR MORPHED CONFIG
[ct_t(mu),b_t(mu),Lift_tail(mu)] = Tail_Resizing_ModuleTP_R4(MTOW_guess(mu),height,v_cr, Static_Margin, b(mu),cr,ct0, b_t0,cr_t,ct_t0, HTVC0);
Tail_Loads_set(mu) = Lift_tail(mu)/cos(D_a);                            % Convert lift to spanwise loading

Mtail(mu) = Wing_Mass_Module_R2(Tail_Loads_set(mu),b_t(mu), cr_t,ct_t0);

%% ACTUATOR MASS / SPACE FOR MORPHED CONFIG

M_ext(mu) = Mwing(mu) .* 0.5.*(Sref(mu)-Sref(1))./Sref(mu);     % Approximate mass of extension, kg

Fric_coeff = 0.3;                               % Static friction coefficient
acc_ext = 2.5;                                  % Acceleration, m/s2
F_ext(mu) = M_ext(mu)*9.81*Fric_coeff + M_ext(mu)*acc_ext;

F = F_ext(mu);
l = 1000*0.5*(b(mu)-b(1));

selected_actuator = FINDACT_r2(F,l,0);
M_act(mu) = selected_actuator(1,4);

space_act(mu) = selected_actuator(1,5)/1000;

Mass_fudge = 1.20;                  % 20 % installation mass extra
Space_fudge = 1.20;                 % 20 % installation space extra

M_act(mu) = (M_act(mu)*2)*Mass_fudge;
space_act(mu) = Space_fudge*space_act(mu);

if space_act < 0.5*(b(mu)-b(1))
    space_act(mu) = 0.5*(b(mu)-b(1));
end

% FUEL LOST FOR MORPHED CONFIG

omega = 0.5;                                    % chordwise % of wing-box chord, refer to wing mass module

Fuel_density = 780;

m_fuel_lost(mu) = Fuel_density*omega*space_act(mu)*0.5.*(ct(1)-ct(mu));

%% RESET GUESS MTOW BASED ON ABOVE VALUES

dM_wing(mu) = Mwing(mu)-Mwing(1);
dM_tail(mu) = Mtail(mu)-Mtail(1);
dM_act(mu) = M_act(mu)-M_act(1);
dM_fuel(mu) = m_fuel_lost(mu);

dMTOW_guess(mu) = dM_wing(mu) + dM_tail(mu) + dM_act(mu) - dM_fuel(mu);

%% SAVE ITERATION OUTPUT
iter_output(count,:) = [dM_wing(1,mu) dM_tail(1,mu) dM_act(1,mu) dM_fuel(1,mu) dMTOW_guess(1,mu)];

filename = 'Iteration Data R.xlsx';
headings = {'Iteration Data'};
% results = [dM_wing;dM_tail;dM_act;dM_fuel;dMTOW_guess];
writecell(headings,filename,'Sheet',mu,'Range','C2');
writematrix(iter_output,filename,'Sheet',mu,'Range','D2');

count = count+1;                        % WHILE-LOOP ITERATION COUNTER

    end                % WHILE LOOP ENDS

count                  % NUMBER OF ITERATIONS TAKEN TO CONVERGE ON MTOW_GUESS

end                    % FOR LOOP END

% MORPHING SIZING

EW_new = EW0 +dM_wing + dM_tail + dM_act;
EW_new = EW_new(2:end);
Mfuel = Mfuel0 - dM_fuel;
Mfuel_lost_new = m_fuel_lost(2:end);

MTOW_new = WTO0+dMTOW_guess(2:end);

b_new = b(2:end);
Sref_new = Sref(2:end);


[E]=Endurance_Morphing_R1(b_new, Sref_new, MTOW_new, EW_new);

Eset = [24 E]


WTOset(1) = WTO0;
WTOset = [WTOset MTOW_new]

EWset = [EW0 EW_new]
EWFset = EWset./WTOset;


% dMTOW_guess=dMTOW_guess(2:end)
results = [b;Sref;WTOset;EWset;EWFset;Eset;dMTOW_guess;Mwing;dM_wing;Mtail;dM_tail;M_act;dM_act;Mfuel;dM_fuel];

filename = 'Morphing_Results_R2_a.xlsx';
headings = {'RESULTS OF SPAN MORPHING (MASTERCODE11)';'Span (m)';'Reference Area (sq.m.)';'MTOW (kg)';'Empty Weight (kg)';'Empty Weight Fraction';'Endurance (hrs)';'Increase in MTOW (kg)';'Wing Mass (kg)';'Increase in Wing Mass (kg)';'Tail Mass (kg)';'Increase in Tail Mass (kg)';'Mass of Actuator (kg)';'Increase in Mass of Actuator (kg)';'Mass of fuel (kg)';'Decrease in mass of fuel (kg)'};

writecell(headings,filename,'Sheet',1,'Range','C2');
writematrix(results,filename,'Sheet',1,'Range','D3');

% headings2 = {'RESULTS OF SPAN MORPHING (MASTERCODE11)';'dM_wing';'dM_tail';'dM_act';'dM_fuel';'dMTOW_guess'};
% writecell(headings2,filename,'Sheet',2,'Range','C2');
% writematrix(iter_output,filename,'Sheet',2,'Range','D3');
pause(inf)

%% PLOT RESIZED WINGS AND TAIL

figure(8)

wingposition = 5.671;

plotwings(cr, ct0, b, wingposition);
hold on

tailposition = wingposition+C_C;

plotwings(cr_t,ct_t0,b_t,tailposition)


%% CONSTRAINT ANALYSIS CHECK

T = 38100/9.81;
% T = 34100/9.81;

% soln = CA_check_R1(WTOset(1),Sref(1),T,CD0(1),k(1),1);  % Dummy check values

% pause(inf)

for i=1:size(E,2)
X = [' Design Point for Span ',num2str(b(i+1)), ' m'];
disp(X)
soln = CA_check_R1(WTOset(i),Sref(i),T,CD0(i),k(i),i);  % Dummy check values
end
